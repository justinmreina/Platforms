/* 
 * Project name:
     HID_Read_Write_Polling (USB HID Read & Write Test)
 * Copyright:
     (c) Mikroelektronika, 2014.
 * Revision History:
     20140901:
       - initial release (FJ);
 * Description:
     This example establishes connection with the HID terminal that is active
     on the PC. Upon connection establishment, the HID Device Name will appear
     in the respective window. The character that user sends to ARM from the HID
     terminal will be re-sent back to user.
 * Test configuration:
     MCU:             STM32F415RG
                      http://www.st.com/st-web-ui/static/active/en/resource/technical/document/datasheet/DM00035129.pdf
     Dev.Board:       STM32 M4 clicker - ac:STM32_M4_clicker
                      http://www.mikroe.com/stm32/clicker/
     Oscillator:      HSI-PLL, 120.000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for ARM
                      http://www.mikroe.com/mikroc/arm/
*/

char cnt;
char kk;
char readbuff[64];
char writebuff[64];

unsigned long int i = 0;
void main(void){

  HID_Enable(&readbuff,&writebuff);

  while(1){
    USB_Polling_Proc();               // Call this routine periodically
    kk = HID_Read();
    if(kk != 0){
      for(cnt=0;cnt<64;cnt++)
        writebuff[cnt]=readbuff[cnt];
      HID_Write(&writebuff,64);
    }
  }
}