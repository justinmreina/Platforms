/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC43xx.h"
#endif

#include "lpc43xx_gpio.h"
#include "lpc43xx_timer.h"

#include <cr_section_macros.h>

volatile uint32_t msec;

// Use Timer0 as CM0 in LPC43xx does not implement the Systick peripheral!
void M0_TIMER0_IRQHandler( void )
{
	if(msec)msec--;
	LPC_TIMER0->IR = TIM_IR_CLR(0);
	NVIC_ClearPendingIRQ(M0_TIMER0_IRQn);

}

#define LED_GPIO_PORT_USED		(1)
#define RED_GPIO_PIN_BIT		(11)

int main(void) {

	// Reset and renable timer (set up by CM4)
    NVIC_DisableIRQ(M0_TIMER0_IRQn);
	NVIC_ClearPendingIRQ(M0_TIMER0_IRQn);
	NVIC_SetPriority(M0_TIMER0_IRQn, ((0x01 << 3) | 0x01));
    NVIC_EnableIRQ(M0_TIMER0_IRQn);

	// Enter an infinite loop, just incrementing a counter
	volatile static int i = 0 ;
	while(1) {
		i++ ;
		msec = 500;
		while(msec);
		// Turn LED on
		GPIO_ClearValue(LED_GPIO_PORT_USED,(1<<RED_GPIO_PIN_BIT));

		msec = 500;
		while(msec);
		// Turn LED off
		GPIO_SetValue(LED_GPIO_PORT_USED,(1<<RED_GPIO_PIN_BIT));

	}
	return 0 ;
}
