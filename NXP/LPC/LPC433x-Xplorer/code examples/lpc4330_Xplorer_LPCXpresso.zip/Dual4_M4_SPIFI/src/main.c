/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC43xx.h"
#endif

#include "lpc43xx_gpio.h"
#include "lpc43xx_scu.h"
#include "lpc43xx_cgu.h"
#include "lpc43xx_timer.h"

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

#define LED_GPIO_PORT_USED		(1)
#define RED_GPIO_PIN_BIT		(11)
#define GREEN_GPIO_PIN_BIT		(6)
#define BLUE_GPIO_PIN_BIT		(8)


#define LED1_BIT			12 //LEDUSB
#define LED1_PORT			1

volatile uint32_t msec;

void SysTick_Handler (void) 					// SysTick Interrupt Handler @ 1000Hz
{
	if(msec)msec--;
}

void start_m0 (void);

int main(void) {

	SysTick_Config(CGU_GetPCLKFrequency(CGU_PERIPHERAL_M4CORE)/1000);

	scu_pinmux(0x2 ,12 , MD_PUP, FUNC0); 	// P8.1 : USB0_IND1 LED

	GPIO_SetDir(LED1_PORT,(1<<LED1_BIT), 1);

	GPIO_SetValue(LED1_PORT,(1<<LED1_BIT));


	// =================================================
	// Set up Red LED from RGB triple Led for use by CM0
	// =================================================
	scu_pinmux(0x2, 11, MD_PUP, FUNC0);
//	scu_pinmux(0xE, 6, MD_PDN, FUNC4);
//	scu_pinmux(0xE, 8, MD_PDN, FUNC4);
	GPIO_SetDir(LED_GPIO_PORT_USED, (1 << RED_GPIO_PIN_BIT), 1);
//	GPIO_SetDir(LED_GPIO_PORT_USED, (1 << GREEN_GPIO_PIN_BIT), 1);
//	GPIO_SetDir(LED_GPIO_PORT_USED, (1 << BLUE_GPIO_PIN_BIT), 1);
	GPIO_SetValue(LED_GPIO_PORT_USED,(1<<RED_GPIO_PIN_BIT));
//	GPIO_SetValue(LED_GPIO_PORT_USED,(1<<GREEN_GPIO_PIN_BIT));
//	GPIO_SetValue(LED_GPIO_PORT_USED,(1<<BLUE_GPIO_PIN_BIT));
#if 0
	GPIO_ClearValue(LED_GPIO_PORT_USED,(1<<BLUE_GPIO_PIN_BIT));
	msec = 1000;
	while(msec);
	GPIO_SetValue(LED_GPIO_PORT_USED,(1<<BLUE_GPIO_PIN_BIT));
	msec = 1000;
	while(msec);
	GPIO_ClearValue(LED_GPIO_PORT_USED,(1<<BLUE_GPIO_PIN_BIT));
	msec = 1000;
	while(msec);
	GPIO_SetValue(LED_GPIO_PORT_USED,(1<<BLUE_GPIO_PIN_BIT));
	msec = 1000;
	while(msec);
	GPIO_ClearValue(LED_GPIO_PORT_USED,(1<<BLUE_GPIO_PIN_BIT));
	msec = 1000;
	while(msec);
	GPIO_SetValue(LED_GPIO_PORT_USED,(1<<BLUE_GPIO_PIN_BIT));
#endif


	// =============================
	// Setup Timer0 - for use by CM0
	// =============================

	TIM_TIMERCFG_Type TIM_ConfigStruct;
	TIM_MATCHCFG_Type TIM_MatchConfigStruct;

	/* Initialize timer 0, prescale count time of 250uS */
	TIM_ConfigStruct.PrescaleOption = TIM_PRESCALE_USVAL;
	TIM_ConfigStruct.PrescaleValue	= 250;

	/* Timer 0, match 0, int on match, reset on match, about 1KHz */
	TIM_MatchConfigStruct.MatchChannel = 0;
	TIM_MatchConfigStruct.IntOnMatch   = TRUE;
	TIM_MatchConfigStruct.ResetOnMatch = TRUE;
	TIM_MatchConfigStruct.StopOnMatch  = FALSE;
	TIM_MatchConfigStruct.ExtMatchOutputType =TIM_EXTMATCH_TOGGLE;
	TIM_MatchConfigStruct.MatchValue   = 4;

	/* Set configuration for Tim_config and Tim_MatchConfig */
	TIM_Init(LPC_TIMER0, TIM_TIMER_MODE,&TIM_ConfigStruct);
	TIM_ConfigMatch(LPC_TIMER0,&TIM_MatchConfigStruct);

	/* Start timer 0 */
	TIM_Cmd(LPC_TIMER0,ENABLE);

	start_m0();



	// Enter an infinite loop, just incrementing a counter
	volatile static int i = 0 ;
	while(1) {
		i++ ;
		msec = 100;
		while(msec);

		GPIO_ClearValue(LED1_PORT,(1<<LED1_BIT));

		msec = 100;
		while(msec);
		GPIO_SetValue(LED1_PORT,(1<<LED1_BIT));

	}
	return 0 ;
}


#ifdef  DEBUG
/*******************************************************************************
* @brief		Reports the name of the source file and the source line number
* 				where the CHECK_PARAM error has occurred.
* @param[in]	file Pointer to the source file name
* @param[in]    line assert_param error line source number
* @return		None
*******************************************************************************/
void check_failed(uint8_t *file, uint32_t line)
{
	/* User can add his own implementation to report the file name and line number,
	 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

	/* Infinite loop */
	while(1);
}
#endif
