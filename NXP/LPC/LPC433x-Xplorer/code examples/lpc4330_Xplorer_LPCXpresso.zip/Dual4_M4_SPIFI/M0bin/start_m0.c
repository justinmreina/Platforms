#include "LPC43xx.h"

// Symbols from m0bin.s to mark where M0 binary has been located
extern unsigned char CM0image_start;

/* Release SLAVE processor from reset */
void IPC_startSlave(void)
{
	volatile uint32_t u32REG, u32Val;

	/* Release Slave from reset, first read status */
	/* Notice, this is a read only register !!! */
	u32REG = LPC_RGU->RESET_ACTIVE_STATUS1;

	/* If the M0 is being held in reset, release it */
	/* 1 = no reset, 0 = reset */
	while(!(u32REG & (1u << 24)))
	{
		u32Val = (~(u32REG) & (~(1 << 24)));
		LPC_RGU->RESET_CTRL1 = u32Val;
		u32REG = LPC_RGU->RESET_ACTIVE_STATUS1;
	};
}

/* put the SLAVE processor back in reset */
void IPC_haltSlave(void) {

	volatile uint32_t u32REG, u32Val;

	/* Check if M0 is reset by reading status */
	u32REG = LPC_RGU->RESET_ACTIVE_STATUS1;

	/* If the M0 has reset not asserted, halt it... */
	/* in u32REG, status register, 1 = no reset */
	while ((u32REG & (1u << 24)))
	{
		u32Val = ( (~u32REG) | (1 << 24));
		LPC_RGU->RESET_CTRL1 = u32Val;
		u32REG = LPC_RGU->RESET_ACTIVE_STATUS1;
	}
}


void start_m0 (void) {
	// Make sure M0 is not running
	IPC_haltSlave();
	// Set M0's vector table to point to start of M0 image
	LPC_CREG->M0APPMEMMAP = (unsigned int)&CM0image_start;
	// Release M0 from reset
	IPC_startSlave();
}
