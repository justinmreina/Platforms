/*
 * m0bin.s
 *
 */
	.align 2
	.section ".data.$RamLoc72.CM0image"

	.global CM0image_start
	.global CM0image_end
CM0image_start:
	.incbin "../M0bin/CM0image.bin"
CM0image_end:
