; --COPYRIGHT--,BSD_EX
;  Copyright (c) 2012, Texas Instruments Incorporated
;  All rights reserved.
; 
;  Redistribution and use in source and binary forms, with or without
;  modification, are permitted provided that the following conditions
;  are met:
; 
;  *  Redistributions of source code must retain the above copyright
;     notice, this list of conditions and the following disclaimer.
; 
;  *  Redistributions in binary form must reproduce the above copyright
;     notice, this list of conditions and the following disclaimer in the
;     documentation and/or other materials provided with the distribution.
; 
;  *  Neither the name of Texas Instruments Incorporated nor the names of
;     its contributors may be used to endorse or promote products derived
;     from this software without specific prior written permission.
; 
;  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
;  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
;  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
;  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
;  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
;  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
;  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
;  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
;  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
;  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
;  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
; 
; ******************************************************************************
;  
;                        MSP430 CODE EXAMPLE DISCLAIMER
; 
;  MSP430 code examples are self-contained low-level programs that typically
;  demonstrate a single peripheral function or device feature in a highly
;  concise manner. For this the code may rely on the device's power-on default
;  register values and settings such as the clock configuration and care must
;  be taken when combining code from several examples to avoid potential side
;  effects. Also see www.ti.com/grace for a GUI- and www.ti.com/msp430ware
;  for an API functional library-approach to peripheral configuration.
; 
; --/COPYRIGHT--
;******************************************************************************
;   MSP430F54xA Demo - Software Toggle P1.0 with 12MHz DCO
;
;   Description: Toggle P1.0 by xor'ing P1.0 inside of a software loop.
;   ACLK is rought out on pin P11.0, SMCLK is brought out on P11.2, and MCLK
;   is brought out on pin P11.1.
;   ACLK = REFO = 32kHz, MCLK = SMCLK = 12MHz
;	PMMCOREV = 1 to support up to 12MHz clock
;
;                 MSP430F5438A
;             -----------------
;         /|\|                 |
;          | |            P11.0|-->ACLK
;          --|RST         P11.1|-->MCLK
;            |            P11.2|-->SMCLK
;            |                 |
;            |             P1.0|-->LED
;
;  	Note: 
;      	In order to run the system at up to 12MHz, VCore must be set at 1.6V 
;		or higher. This is done by invoking function SetVCore().
;
;   F. Chen
;   Texas Instruments Inc.
;   December 2012
;   Built with CCS Version: 5.2.1 
;******************************************************************************

    .cdecls C,LIST,"msp430.h"
;-------------------------------------------------------------------------------
            .def    RESET                   ; Export program entry-point to
                                            ; make it known to linker.
;-------------------------------------------------------------------------------
            .global _main 
            .text                           ; Assemble to Flash memory
;-------------------------------------------------------------------------------
_main
RESET       mov.w   #0x5C00,SP              ; Initialize stackpointer
            mov.w   #WDTPW+WDTHOLD,&WDTCTL  ; Stop WDT
            
            mov.w	#PMMCOREV_1, R12		; Set VCore to 1.6V to support 12MHz clock 
            calla	#SetVCore				
            bis.b   #BIT0,&P1DIR            ; P1.0 output
            bis.b   #0x07,&P11DIR           ; ACLK, MCLK, SMCLK set out to pins
            bis.b   #0x07,&P11SEL           ; P11.0, 1, 2 for debugging purposes
            ; Initialize clocks
            bis.w   #SELREF_2,&UCSCTL3      ; Set DCO FLL reference = REFO
            bis.w   #SELA_2,&UCSCTL4        ; Set ACLK = REFO

            bis.w   #SCG0,SR                ; Disable the FLL control loop
            clr.w   &UCSCTL0                ; Set lowest possible DCOx, MODx
            mov.w   #DCORSEL_5,&UCSCTL1     ; Select range for 24 MHz operation
            mov.w   #FLLD_1 + 366,&UCSCTL2  ; Set DCO multiplier for 12 MHz
                                            ; (N + 1) * FLLRef = Fdco
                                            ; (366 + 1) * 32768 = 12MHz
                                            ; Set FLL Div = fDCOCLK/2
            bic.w   #SCG0,SR                ; Enable the FLL control loop

  ; Worst-case settling time for the DCO when the DCO range bits have been
  ; changed is n x 32 x 32 x f_FLL_reference. See UCS chapter in 5xx UG
  ; for optimization.
  ; 32 x 32 x 12 MHz / 32,768 Hz = 375000 = MCLK cycles for DCO to settle
            mov.w   #0x6E34,R15
            nop
            mov.w   #0x1,R14
delay_L1    add.w   #0xFFFF,R15
            addc.w  #0xFFFF,R14
            jc      delay_L1

            ; Loop until XT1,XT2 & DCO fault flag is cleared
do_while    bic.w   #XT2OFFG + XT1LFOFFG + XT1HFOFFG + DCOFFG,&UCSCTL7
                                            ; Clear XT2,XT1,DCO fault flags
            bic.w   #OFIFG,&SFRIFG1         ; Clear fault flags
            bit.w   #OFIFG,&SFRIFG1         ; Test oscillator fault flag
            jc      do_while

while_loop  xor.b   #BIT0,&P1OUT            ; Flash the LED
            mov.w   #0xFFFF,R4              ; Initialize loop counter R4=65535
delay_loop  dec.w   R4                      ; Decrement loop counter
            jne     delay_loop              ; Loop if loop counter > 0
            jmp     while_loop              ; Infinite while loop
;-------------------------------------------------------------------------------
SetVCore   ; SetVCore function
           ; In order to support high speed MCLK , The voltage level of Vcore  must be sufficiently high
           ; The voltage level of Vcore must be increased by one step one time
;-------------------------------------------------------------------------------
            mov.b   #PMMPW_H, &PMMCTL0_H     ;Open PMM registers for write
   ;  Set SVS/SVM high side new level
            mov.w   R12,R15                 ; R12--->R15
			and.w   #0xff,R15
            swpb    R15                     ;exchange the high and low byte of R15
            add.w   R12,R15                 ;add src to dst src+dst--->dst
            add.w   #0x4400,R15             ;SVM high-side enable ,SVS high-side enable
            mov.w   R15,&SVSMHCTL            ;
   ;  Set SVM low side to new level
			mov.w   R12,R15
			add.w   #0x4400,R15
			mov.w   R15,&SVSMLCTL
   ; Wait till SVM is settled
do_while1   bit.w   #SVSMLDLYIFG,&PMMIFG     ; Test SVSMLDLYIFG
			jz     do_while1
   ; Clear already set flags
            bic.w   #SVMLIFG,&PMMIFG         ;clear SVM low-side interrupt flag
            bic.w   #SVMLVLRIFG,&PMMIFG      ;clear  SVM low-side voltage level reached interrupt flag
   ; Set VCore to new level
            mov.b  R12,&PMMCTL0_L
   ; Wait till new level reached
            bit.w   #SVMLIFG,&PMMIFG
            jz     low_set
do_while2   bit.w   #SVMLVLRIFG,&PMMIFG      ; Test SVMLvLrIFG
			jz     do_while2
    ;Set SVS/SVM low side to new level
low_set     mov.w   R12,R15
            and.w   #0xff,R15
            swpb    R15
            add.w   R15,R12
            add.w   #0x4400,R12
            mov.w   R12,&SVSMLCTL
	;Lock PMM registers for write access
			clr.b   &PMMCTL0_H
            RETA

;-------------------------------------------------------------------------------
                  ; Interrupt Vectors
;-------------------------------------------------------------------------------
            .sect   ".reset"                ; POR, ext. Reset
            .short  RESET
            .end
