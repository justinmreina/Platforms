/************************************************************************************************************************************/
/** @file       main.c
 *  @brief      WISP-Tx Demo for ASK validation on Rx-Circuit board
 *  @details    x
 *
 *  @target     MSP430F2132
 *  @board      WISP 4.1DL
 *
 *  @author     Justin Reina, Firmware Engineer, Misc. Company
 *  @created    7/22/17
 *  @last rev   7/22/17
 *
 *  @section    Opens
 *          none current
 *
 *  @section    Legal Disclaimer
 *          All contents of this source file and/or any other Misc. Product related source files are the explicit property of
 *          Misc. Company. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
#include <stdint.h>
#include <msp430.h>				


uint32_t i,j;                                                               /* volatile to prevent optimization                     */

/**
 *  @note     chip=12.5us
 */
int main(void) {
	WDTCTL = WDTPW | WDTHOLD;		                                        /* Stop watchdog timer                                  */

    DCOCTL = CALDCO_16MHZ;                                                  /* Set clock (16 MHz)                                   */
    BCSCTL1 = CALBC1_16MHZ;

	P1DIR |= BIT1;                                                          /* Transmit_RFID                                        */
	P3DIR |= BIT0;					                                        /* WISP.P3.8                                            */

	for(;;) {

	    //Packet of Chips (~1ms)
	    for(i=80; i>0; i--) {
	        P1OUT ^= BIT1;                                                  /* Toggle P3.0, WISP Transmit Pin                       */
	        P3OUT ^= BIT0;                                                  /* Debug Inspect                                        */
	        for(j=9; j>0; j--) { asm(" NOP"); }                             /* Small Delay to hit ~12.5us loop                      */
	    }

	    //Exit-Low
	    P1OUT &= ~BIT1;
	    P3OUT &= ~BIT0;

	    //Delay (~1ms)
		for(i=850; i>0; i--) { asm(" NOP"); }                               /* SW Delay                                             */
	}
}

