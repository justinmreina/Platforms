#include <msp430.h> 

/*
 * main.c
 */
int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	

    P4DIR |= (BIT0+BIT1+BIT2+BIT3);

    P4OUT ^= (BIT0+BIT1+BIT2+BIT3);

    P4OUT ^= (BIT0+BIT1+BIT2+BIT3);

    P4OUT ^= (BIT0+BIT1+BIT2+BIT3);

    P4OUT ^= (BIT0+BIT1+BIT2+BIT3);

	return 0;
}
