# FIXED

blink.obj: ../blink.c
blink.obj: C:/ti/ccsv7/ccs_base/msp430/include/msp430.h
blink.obj: C:/ti/ccsv7/ccs_base/msp430/include/msp430f2132.h
blink.obj: C:/ti/ccsv7/ccs_base/msp430/include/in430.h
blink.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-msp430_17.6.0.STS/include/intrinsics.h
blink.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-msp430_17.6.0.STS/include/intrinsics_legacy_undefs.h

../blink.c: 
C:/ti/ccsv7/ccs_base/msp430/include/msp430.h: 
C:/ti/ccsv7/ccs_base/msp430/include/msp430f2132.h: 
C:/ti/ccsv7/ccs_base/msp430/include/in430.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-msp430_17.6.0.STS/include/intrinsics.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-msp430_17.6.0.STS/include/intrinsics_legacy_undefs.h: 
