#ifndef GLOBALS_H_
#define GLOBALS_H_

//Libraries
#include <stdlib.h>

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Task.h>

/* TI-RTOS Header files */
// #include <ti/drivers/I2C.h>
#include <ti/drivers/PIN.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>

/* Board Header files */
#include "Board.h"


//Defs
#define TASKSTACKSIZE                       (512)
#define MAX_NUM_HEARBEAT_PRINTS             (75)                            /* arb selection                                        */

//Global Defs
#define sprintf     System_sprintf                                          /* use cleaner syntax                                   */


//Locals
void sys_init(void);
void demo_print(void);
void printf(char *str);




#endif /* GLOBALS_H_ */

