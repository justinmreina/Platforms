/************************************************************************************************************************************/
/** @file       main.c
 *  @brief      template for TI-RTOS use on CC2650
 *  @details    sourced from TI-RTOS Empty(std) Project with no major modifications
 *
 *  @target     CC2650F128
 *  @board      SimpleLink CC2650 LaunchPad - LAUNCHXL-CC2650
 *
 *  @group      WCS, BTS
 *  @devices    CC2650, CC2640, CC1350
 *
 *  @release    ble_sdk_2_02_01_18
 *  @date       2016-10-26 15:20:04
 *
 *  @author     Justin Reina, Firmware Engineer, Misc. Company
 *  @created    5/22/17
 *  @last rev   5/22/17
 *
 *
 *  @notes      x
 *
 *  @section    Opens
 *          none current
 *
 *  @section    Legal Disclaimer
 *          All contents of this source file and/or any other Misc. Product related source files are the explicit property of
 *          Misc. Company. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
#include "globals.h"

//Task Vars
Task_Struct task0Struct;
Char task0Stack[TASKSTACKSIZE];

//Peripheral Vars
static PIN_Handle ledPinHandle;                                             /* Pin driver handle                                    */
static PIN_State ledPinState;

//Demo Vars
uint32_t blinkPrint_ct;

//Application LED pin configuration table - All LEDs board LEDs are off
PIN_Config ledPinTable[] = {
    Board_LED0 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    Board_LED1 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};


/************************************************************************************************************************************/
/** @fcn        void heartBeatFxn(UArg arg0, UArg arg1)
 *  @brief      Toggle the Board_LED0. The Task_sleep is determined by arg0 which is configured for the heartBeat Task instance
 *
 *  @param      [in]    (UArg) arg0, arg1   TI-RTOS Task Input Parameters passed to the Task Subroutine
 */
/************************************************************************************************************************************/
void heartBeatFxn(UArg arg0, UArg arg1) {

    //Display Serial Use
    demo_print();

    for(;;) {

        //Pin Toggle
        PIN_setOutputValue(ledPinHandle, Board_LED0, !PIN_getOutputValue(Board_LED0));

        //Print User Notification
        if(blinkPrint_ct++ < MAX_NUM_HEARBEAT_PRINTS) {
                System_printf("X");
                System_flush();
        }

        //Loop Delay
        Task_sleep((UInt)arg0);
    }
}


/************************************************************************************************************************************/
/** @fcn        int main(void)
 *  @brief      x
 *  @details    x
 */
/************************************************************************************************************************************/
int main(void) {

    //Init
    sys_init();

    //Start BIOS
    BIOS_start();

    return EXIT_SUCCESS;
}


/************************************************************************************************************************************/
/** @fcn        void sys_init(void)
 *  @brief      initialize the system & mcu for use on boot
 *  @details    x
 */
/************************************************************************************************************************************/
void sys_init(void) {

    uint32_t clkPeriod = Clock_tickPeriod;                                  /* for user inspection. set to '10' us in empty.cfg     */

    //vars init
    blinkPrint_ct = 0;

    Task_Params taskParams;

    /* Call board init functions */
    Board_initGeneral();
    // Board_initI2C();
    // Board_initSPI();
    // Board_initUART();
    // Board_initWatchdog();

    /* Construct heartBeat Task  thread */
    Task_Params_init(&taskParams);
    taskParams.arg0 = 1000000/4/clkPeriod;
    taskParams.stackSize = TASKSTACKSIZE;
    taskParams.stack = &task0Stack;

    Task_construct(&task0Struct, (Task_FuncPtr)heartBeatFxn, &taskParams, NULL);

    /* Open LED pins */
    ledPinHandle = PIN_open(&ledPinState, ledPinTable);
    if(!ledPinHandle) {
        System_abort("Error initializing board LED pins\n");
    }

    PIN_setOutputValue(ledPinHandle, Board_LED1, 1);

    return;
}


/**
 */
/************************************************************************************************************************************/
/** @fcn        void demo_print(void)
 *  @brief      demo use of serial output
 *
 *  @pre    Serial is initialized
 */
/************************************************************************************************************************************/
void demo_print(void) {

    uint32_t clkPeriod = Clock_tickPeriod;                                  /* for user inspection. set to '10' us in empty.cfg     */

    char outputBuff[100];

    //Sprintf test
    sprintf(outputBuff, "Test %d %s\n", 12345, "Justin");

    //Message
    printf("\n");                                                           /* to delineate from entry console print already        */
    printf("Starting the example.\n");
    Task_sleep(1000000/4/clkPeriod);

    printf("System provider is set to SysMin.\n");
    Task_sleep(1000000/4/clkPeriod);

    printf("Halt the target to view any SysMin contents in ROV.\n");
    Task_sleep(1000000/4/clkPeriod);

    printf(outputBuff);
    Task_sleep(1000000/4/clkPeriod);

    return;
}


/************************************************************************************************************************************/
/** @fcn        void printf(char *str)
 *  @brief      print a string to the output serial
 *
 *  @param      [in]    (char *)str     string to print out (EOS terminated)
 */
/************************************************************************************************************************************/
void printf(char *str) {

    System_printf(str);

    System_flush();                                         /* SysMin will only print to the console when you call flush or exit    */

    return;
}

