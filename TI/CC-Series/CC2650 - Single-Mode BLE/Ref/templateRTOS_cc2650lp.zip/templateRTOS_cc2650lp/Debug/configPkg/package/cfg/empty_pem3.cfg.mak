# invoke SourceDir generated makefile for empty.pem3
empty.pem3: .libraries,empty.pem3
.libraries,empty.pem3: package/cfg/empty_pem3.xdl
	$(MAKE) -f D:\Documents\MyWorkspaces\CCS\CC2650_Template\templateRTOS_cc2650lp\sys/src/makefile.libs

clean::
	$(MAKE) -f D:\Documents\MyWorkspaces\CCS\CC2650_Template\templateRTOS_cc2650lp\sys/src/makefile.libs clean

