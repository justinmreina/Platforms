# FIXED

sys/ccfg.obj: ../sys/ccfg.c
sys/ccfg.obj: C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272/startup_files/ccfg.c
sys/ccfg.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/stdint.h
sys/ccfg.obj: C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272/inc/hw_types.h
sys/ccfg.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/stdbool.h
sys/ccfg.obj: C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272/inc/hw_chip_def.h
sys/ccfg.obj: C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272/inc/hw_ccfg.h
sys/ccfg.obj: C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272/inc/hw_ccfg_simple_struct.h

../sys/ccfg.c: 
C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272/startup_files/ccfg.c: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/stdint.h: 
C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272/inc/hw_types.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/stdbool.h: 
C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272/inc/hw_chip_def.h: 
C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272/inc/hw_ccfg.h: 
C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272/inc/hw_ccfg_simple_struct.h: 
