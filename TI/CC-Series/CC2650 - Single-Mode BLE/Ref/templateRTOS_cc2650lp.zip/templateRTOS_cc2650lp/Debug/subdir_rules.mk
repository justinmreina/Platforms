################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
main.obj: ../main.c $(GEN_OPTS) | $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/bin/armcl" -mv7M3 --code_state=16 --float_support=vfplib -me --include_path="D:/Documents/MyWorkspaces/CCS/CC2650_Template/templateRTOS_cc2650lp/sys" --include_path="D:/Documents/MyWorkspaces/CCS/CC2650_Template/templateRTOS_cc2650lp" --include_path="D:/Documents/MyWorkspaces/CCS/CC2650_Template/templateRTOS_cc2650lp" --include_path="C:/ti/lib/tirtos_cc13xx_cc26xx_2_21_00_06/products/cc26xxware_2_24_03_17272" --include_path="C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include" --define=ccs -g --diag_warning=225 --diag_warning=255 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --preproc_with_compile --preproc_dependency="main.d" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '


