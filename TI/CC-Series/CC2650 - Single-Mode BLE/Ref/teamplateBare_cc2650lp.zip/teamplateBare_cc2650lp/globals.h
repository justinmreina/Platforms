#ifndef GLOBALS_H_
#define GLOBALS_H_

//Libraries
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>


#endif /* GLOBALS_H_ */

