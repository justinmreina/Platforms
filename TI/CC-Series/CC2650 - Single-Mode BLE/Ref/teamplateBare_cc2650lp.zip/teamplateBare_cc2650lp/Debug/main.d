# FIXED

main.obj: ../main.c
main.obj: ../globals.h
main.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/stdlib.h
main.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/linkage.h
main.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/stdint.h
main.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/stdbool.h

../main.c: 
../globals.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/stdlib.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/linkage.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/stdint.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include/stdbool.h: 
