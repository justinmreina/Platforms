#ifndef GLOBALS_H_
#define GLOBALS_H_


//Project Configuration
#define USES_DRM        (1)
//#define USES_LIB      (1)


//Libraries
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>


#endif /* GLOBALS_H_ */
