# FIXED

main.obj: ../main.c
main.obj: ../globals.h
main.obj: M:/sw/ti/ccsv7/tools/compiler/ti-cgt-arm_16.12.0.STS/include/stdlib.h
main.obj: M:/sw/ti/ccsv7/tools/compiler/ti-cgt-arm_16.12.0.STS/include/linkage.h
main.obj: M:/sw/ti/ccsv7/tools/compiler/ti-cgt-arm_16.12.0.STS/include/stdint.h
main.obj: M:/sw/ti/ccsv7/tools/compiler/ti-cgt-arm_16.12.0.STS/include/stdbool.h

../main.c: 
../globals.h: 
M:/sw/ti/ccsv7/tools/compiler/ti-cgt-arm_16.12.0.STS/include/stdlib.h: 
M:/sw/ti/ccsv7/tools/compiler/ti-cgt-arm_16.12.0.STS/include/linkage.h: 
M:/sw/ti/ccsv7/tools/compiler/ti-cgt-arm_16.12.0.STS/include/stdint.h: 
M:/sw/ti/ccsv7/tools/compiler/ti-cgt-arm_16.12.0.STS/include/stdbool.h: 
