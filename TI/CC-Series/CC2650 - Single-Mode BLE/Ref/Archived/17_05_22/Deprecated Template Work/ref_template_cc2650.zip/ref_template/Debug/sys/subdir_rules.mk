################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
sys/startup_ccs.obj: C:/ti/lib/tirtos_cc13xx_cc26xx_2_20_01_08/products/cc26xxware_2_24_02_17393/startup_files/startup_ccs.c $(GEN_OPTS) | $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/bin/armcl" -mv7M3 --code_state=16 -me --include_path="D:/Documents/MyWorkspaces/CCS/CC2650_SimpleLink/ref_template" --include_path="C:/ti/lib/tirtos_cc13xx_cc26xx_2_20_01_08/products/cc26xxware_2_24_02_17393" --include_path="C:/ti/ccsv7/tools/compiler/ti-cgt-arm_17.3.0.STS/include" -g --diag_warning=225 --diag_wrap=off --display_error_number --abi=eabi --preproc_with_compile --preproc_dependency="sys/startup_ccs.d" --obj_directory="sys" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '


