################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../sys/cc26x0f128.cmd 

C_SRCS += \
C:/ti/lib/tirtos_cc13xx_cc26xx_2_20_01_08/products/cc26xxware_2_24_02_17393/startup_files/startup_ccs.c 

C_DEPS += \
./sys/startup_ccs.d 

OBJS += \
./sys/startup_ccs.obj 

OBJS__QUOTED += \
"sys\startup_ccs.obj" 

C_DEPS__QUOTED += \
"sys\startup_ccs.d" 

C_SRCS__QUOTED += \
"C:/ti/lib/tirtos_cc13xx_cc26xx_2_20_01_08/products/cc26xxware_2_24_02_17393/startup_files/startup_ccs.c" 


