#include <msp430.h> 

/*
 * main.c
 */
int main(void) {


	volatile int i=0;

	i++;

	P1OUT |= BIT0;
	
	return 0;
}
