# FIXED

tm4c1294ncpdt_startup_ccs.obj: ../tm4c1294ncpdt_startup_ccs.c
tm4c1294ncpdt_startup_ccs.obj: M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/stdint.h

../tm4c1294ncpdt_startup_ccs.c: 
M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/stdint.h: 
