# FIXED

main.obj: ../main.c
main.obj: M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/stdint.h
main.obj: M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/stdbool.h
main.obj: M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/yvals.h
main.obj: M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/stdarg.h
main.obj: M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/linkage.h
main.obj: M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/_lock.h
main.obj: M:/sw/ti/lib/TivaWare_C_Series-2.1.3.156/inc/hw_memmap.h
main.obj: M:/sw/ti/lib/TivaWare_C_Series-2.1.3.156/inc/tm4c1294ncpdt.h
main.obj: M:/sw/ti/lib/TivaWare_C_Series-2.1.3.156/driverlib/gpio.h

../main.c: 
M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/stdint.h: 
M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/stdbool.h: 
M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/yvals.h: 
M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/stdarg.h: 
M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/linkage.h: 
M:/sw/ti/ccsv6/tools/compiler/arm_5.2.8/include/_lock.h: 
M:/sw/ti/lib/TivaWare_C_Series-2.1.3.156/inc/hw_memmap.h: 
M:/sw/ti/lib/TivaWare_C_Series-2.1.3.156/inc/tm4c1294ncpdt.h: 
M:/sw/ti/lib/TivaWare_C_Series-2.1.3.156/driverlib/gpio.h: 
