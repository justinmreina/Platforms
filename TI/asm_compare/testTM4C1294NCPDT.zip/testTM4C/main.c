#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/tm4c1294ncpdt.h"
#include "driverlib/gpio.h"

/*
 * main.c
 */
int main(void) {

	volatile int i=0;

	i++;

	GPIO_PORTA_AHB_DATA_R |= 0x01;
	
	return 0;
}

