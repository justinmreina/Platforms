# FIXED

main.obj: ../main.c
main.obj: M:/sw/ti/ccsv6/ccs_base/msp430/include/msp430.h
main.obj: M:/sw/ti/ccsv6/ccs_base/msp430/include/msp430f5529.h
main.obj: M:/sw/ti/ccsv6/ccs_base/msp430/include/in430.h
main.obj: M:/sw/ti/ccsv6/tools/compiler/ti-cgt-msp430_16.6.0.STS/include/intrinsics.h
main.obj: M:/sw/ti/ccsv6/tools/compiler/ti-cgt-msp430_16.6.0.STS/include/intrinsics_legacy_undefs.h

../main.c: 
M:/sw/ti/ccsv6/ccs_base/msp430/include/msp430.h: 
M:/sw/ti/ccsv6/ccs_base/msp430/include/msp430f5529.h: 
M:/sw/ti/ccsv6/ccs_base/msp430/include/in430.h: 
M:/sw/ti/ccsv6/tools/compiler/ti-cgt-msp430_16.6.0.STS/include/intrinsics.h: 
M:/sw/ti/ccsv6/tools/compiler/ti-cgt-msp430_16.6.0.STS/include/intrinsics_legacy_undefs.h: 
