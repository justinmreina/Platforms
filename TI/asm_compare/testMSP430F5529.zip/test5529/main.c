#include <msp430.h> 

/*
 * main.c
 */
int main(void) {

	volatile int i=0;

	i++;

	PAOUT |= BIT0;
	
	return 0;
}
