/**
  @page HAL_TimeBase_RTC_Alarm HAL TimeBase RTC Alarm
  
  @verbatim
  ******************** (C) COPYRIGHT 2016 STMicroelectronics *******************
  * @file    HAL/HAL_TimeBase_RTC_ALARM/readme.txt 
  * @author  MCD Application Team
  * @brief   Description of the HAL TimeBase RTC Alarm example.
  ******************************************************************************
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  @endverbatim

@par Example Description 

This example describes how to customize the HAL time base using RTC alarm instead 
of Systick as main source of time base. The User push-button will be used 
to Suspend or Resume tick increment. 
Each time the button is pressed; an interrupt is generated (EXTI_Line4_15)
and in the ISR the uwIncrementState is checked:
  1- If the uwIncrementState = 0: the tick increment is suspended by calling 
     HAL_SuspendTick() API (RTC alarm interrupt is disabled).
  2- If the uwIncrementState = 1: the tick increment is Resumed by calling 
     HAL_ResumeTick() API(RTC alarm interrupt is enabled).

The alarm is configured to assert an interrupt when the RTC reaches 1 ms 

The example brings, in user file, a new implementation of the following HAL weak functions:

HAL_InitTick() 
HAL_SuspendTick()
HAL_ResumeTick()

This implementation will overwrite native implementation in stm32f0xx_hal.c
and so user functions will be invoked instead when called.

The following time base functions are kept as implemented natively:

HAL_IncTick()
HAL_Delay()

In an infinite loop, LED2 toggles spaced out over 500ms delay, except when tick increment is suspended.

@note Care must be taken when using HAL_Delay(), this function provides accurate delay (in milliseconds)
      based on variable incremented in HAL time base ISR. This implies that if HAL_Delay() is called from
      a peripheral ISR process, then the HAL time base interrupt must have higher priority (numerically lower)
      than the peripheral interrupt. Otherwise the caller ISR process will be blocked.
      To change the HAL time base interrupt priority you have to use HAL_NVIC_SetPriority() function.
      
@note The application needs to ensure that the HAL time base is always set to 1 millisecond
      to have correct HAL operation.


@par Directory contents  

  - HAL/HAL_TimeBase_RTC_ALARM/Inc/stm32f0xx_hal_conf.h               HAL configuration file
  - HAL/HAL_TimeBase_RTC_ALARM/Inc/stm32f0xx_it.h                     Interrupt handlers header file
  - HAL/HAL_TimeBase_RTC_ALARM/Inc/main.h                             Header for main.c module  
  - HAL/HAL_TimeBase_RTC_ALARM/Src/stm32f0xx_it.c                     Interrupt handlers
  - HAL/HAL_TimeBase_RTC_ALARM/Src/main.c                             Main program
  - HAL/HAL_TimeBase_RTC_ALARM/Src/stm32f0xx_hal_timebase_rtc_alarm.c HAL time base rtc alarm functions
  - HAL/HAL_TimeBase_RTC_ALARM/Src/system_stm32f0xx.c                 STM32F0xx system source file

@par Hardware and Software environment

  - This example runs on STM32F091xx devices.
    
  - This example has been tested with STMicroelectronics STM32F091RC-Nucleo RevC board and can be
    easily tailored to any other supported device and development board.      

@par How to use it ? 

In order to make the program work, you must do the following :
 - Open your preferred toolchain 
 - Rebuild all files and load your image into target memory
 - Run the example

 * <h3><center>&copy; COPYRIGHT STMicroelectronics</center></h3>
 */
