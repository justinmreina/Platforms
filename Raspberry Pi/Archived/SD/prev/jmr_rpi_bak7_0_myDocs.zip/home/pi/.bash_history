sudo shutdown now
sudo nano /etc/default/keyboard 
sudo raspi-config 
cvt 1920 1080 60
exit
sudo vi /boot/config.txt 
sudo reboot
pwd
ls -al
sudo rm -rf  Music/ Pictures/ Videos/ Public/ python_games/ Templates/
clear
ls -al
exit
hostname
sudo vi /etc/hostname 
hostname
sudo vi /etc/hosts
hostname
sudo reboot
hostname
exit
sudo nano /usr/share/raspi-ui-overrides/applications/lxterminal.desktop 
clear
sudo nano /etc/network/interfaces
sudo reboot
ping google.com
sudo apt-get install ping
ping google.com
sudo apt-get install iputils-ping 
ping google.com
ping www.google.com
clear
ping 192.168.1.45
exit
ping google.com
ping www.google.com
exit
sudo nano /etc/network/interfaces
sudo reboot
ping 192.168.1.45
exit
ping 192.168.1.45
sudo nano /etc/network/interfaces
sudo reboot
sudo nano /etc/network/interfaces
sudo reboot
ping 192.168.1.45
exir
exit
sudo nano /etc/dhcpcd.c
sudo nano /etc/dhcpcd.conf 
sudo reboot
ping 192.168.1.45
exit
ping 192.168.1.45
exit
hostname
exit
sudo nano /etc/network/interfaces
sudo reboot
sudo nano /etc/network/interfaces
sudo reboot
sudo nano /etc/network/interfaces
sudo nano /etc/dhcpcd.conf 
sudo reboot
ping 192.168.1.45
clear
sudo nano /etc/dhcpcd.conf 
exit
ping 192.168.1.45
exit
clear
sudo nano /etc/network/interfaces
cat /etc/network/interfaces
sudo reboot
ipconfig /release
sudo raspi-config 
exit
sudo apt-get install menu
sudo apt-get install menu-xdg
sudo apt-get install menu-l10n 
exit
sudo apt-get install nano scite gitk x11vnc gitk libc6 libc6-dev 
sudo apt-get install nano scite
sudo apt-get install gitk
sudo apt-get install x11vnc
sudo apt-get install x11vnc --fix-missing
clear
sudo apt-get install libc6 libc6-dev
sudo apt-get install libconfig-dev libconfig++-dev
sudo apt-get install libpango1.0-dev libcogl-pango20-dbg libcogl-pango20
sudo apt-get install libcairo2-dev libcairo2 libatk1.0* build-essential 
sudo apt-get install gtk+-2.0 libgtk-3* libgtk2.0-dev 
sudo apt-get install libfelix-shell-java
sudo apt-get install icedtea-plugin default-jdk default-jre
java -v
java -h
clear
sudo apt-get update
sudo apt-get upgrade
sudo reboot
sudo apt-get purge wiringPi
sudo apt-get install git-core
sudo apt-get update
sudo apt-get upgrade 
sudo reboot
cd ~
cd /
cd usr/include/
vi .gitignore
sudo vi .gitignore
sudo git init
sudo git add * .gitignore
sudo git commit
sudo git config --global user.name "Justin Reina"
sudo git config --global user.email "justinmreina@gmail.com"
sudo git commit
git status
clear
pwd
cd
pwd
clear
sudo git clone git://git.drogon.net/wiringPi
cd wiringPi/
sudo git pull origin
sudo ./build 
gpio -v
gpio readall
gpio read 0
clear
ls -al
sudo mv ~/Desktop/libwiringPi.so wiringPi/
pwd
git status
sudo vi .gitignore 
git status
git add *
sudo git add *
sudo git commit
git status
sudo git add .gitignore
git status
sudo git commit --amend
y
git status
clear
sudo apt-get update
exit
sudo bluetoothctl 
clear
sudo apt-get install bluez libbluetooth-dev libbluetooth3 libbluetooth3-dbg 
sudo route add default gw 10.1.10.1 dev wlan0
sudo apt-get update
sudo apt-get upgrade 
sudo apt-get upgrade -y
sudo apt-get dist-upgrade -y
sudo rpi-update 
sudo reboot
sudo raspi-config 
ifconfig
ifconfig eth0
exit
make
exit
make clean
ls -al
make
ls -al
exirt
exit
make clean
ls -al
make
ls -al
clear
./main.o 
exit
sudo apt-get install eclipse eclipse-cdt eclipse-cdt-autotools eclipse-cdt-launch-remote 
sudo apt-get upgrade
clear
sudo reboot
pwd
mkdir remote-debugging
cd remote-debugging/
touch .gdbinit
chmod 777 .gdbinit 
chmod +x .gdbinit 
exit
ping 192.168.1.45
sudo nano /boot/config.txt 
sudo reboot
sudo chmod 777 ~/remote-debugging/gdbserver 
sudo chmod +x ~/remote-debugging/gdbserver 
vi .gitignore
git init
git add * .gitignore 
git status
git add .Xauthority .asoundrc .bash_* .bas* .*
git add .Xauthority .asoundrc .bash_* .bas* 
clear
git status
git add .cache/ .config/ .dbus/ .profile .xsession-errors*
git status
git add .themes/ .local/ .gstreamer-0.10/ .oracle_jre_usage/
git status
git commit
git log
git config --global user.name "Justin Reina"
git config --global user.email "justinmreina@gmail.com"
git commit
git status
git add .gitignore .cache/*
git status
git add .gitignore 
git status
git add .gitignore 
git status
git commit --amend
clear
git status
git reset --hard
git status
rm .gitignore 
git status
git reset --hard
git status
exit
chmod +x /home/pi/remote-debugging/ref_file;exit
chmod 777 /home/pi/remote-debugging/ref_file; cd /home/pi/remote-debugging;/home/pi/remote-debugging/gdbserver  :2345 /home/pi/remote-debugging/ref_file;exit
ping 192.168.1.45
exit
chmod +x /home/pi/remote-debugging/RPi3_Template_Project;exit
chmod 777 /home/pi/remote-debugging/RPi3_Template_Project; cd /home/pi/remote-debugging;/home/pi/remote-debugging/gdbserver  :2345 /home/pi/remote-debugging/RPi3_Template_Project;exit
chmod +x /home/pi/remote-debugging/RPi3_Template_Project;exit
chmod 777 /home/pi/remote-debugging/RPi3_Template_Project; cd /home/pi/remote-debugging;/home/pi/remote-debugging/gdbserver  :2345 /home/pi/remote-debugging/RPi3_Template_Project;exit
