/************************************************************************************************************************************/
/** @file		main.c
 * 	@brief		show how GPIO is used
 * 	@details	x
 *
 *  @target		Broadcom BCM2837
 *	@board		Raspberry Pi 3 - Model B r1.2
 *
 * 	@author		Justin Reina, Firmware Engineer, Misc. Company
 * 	@created	1/19/17
 * 	@last rev	1/26/17
 *
 *  @section	Opens
 *  		WiringPiSetupPhy()!
 *
 *  @section	Reference
 *  	ISR - http://cs.smith.edu/dftwiki/index.php/Tutorial:_Interrupt-Driven_Event-Counter_on_the_Raspberry_Pi
 */
/************************************************************************************************************************************/
#include "globals.h"


//Globals
uint32_t eventCt;
char str[100];															/* general buffer for sprintf gen							*/


/************************************************************************************************************************************/
/**	@fcn		int main(void)
 *  @brief		illustration of wiringPi use, for I and O
 */
/************************************************************************************************************************************/
int main(void) {

	sys_init();

	flashDemo();

	return EXIT_SUCCESS;
}


/************************************************************************************************************************************/
/**	@fcn		void flashDemo(void)
 *  @brief		shows using wiringPi, confirms it is working!
 */
/************************************************************************************************************************************/
void flashDemo(void) {

	printf("Raspberry Pi blink demo\n");

	for(;;) {
		printf("blink...\n");

		bool sw0 = digitalRead(INPUT_PIN_NUM);								/* read a switch										*/

		sprintf(str, "SW: %x\n", sw0);
		printf(str);

		digitalWrite (OUTPUT_PIN_NUM, HIGH);								/* On													*/
		delay(FLASHDELAY_MS);												/* mS													*/

		digitalWrite(OUTPUT_PIN_NUM, LOW);									/* Off													*/
		delay(FLASHDELAY_MS);												/* mS													*/
	}
}


/************************************************************************************************************************************/
/**	@fcn		void sys_init(void)
 *  @brief		initialize the system on boot
 *
 *  @pre		any
 *  @post		LED set to Output & Low, SW set to Input w/Pullup
 *
 *  @section	Options
 *  		wiringPiSetup			- Use the WiringPi Numbering   (e.g.  0, 'GPIO0')
 *  		wiringPiSetupPhy		- Use the J8 Pinout Numbering  (e.g. 11, 'PIN11')
 *  		wiringPiSetupGpio		- Use the BCM Pinout Numbering (e.g. 17, 'GPIO17')
 */
/************************************************************************************************************************************/
void sys_init(void) {

	//Initialize Globals
	eventCt = 0;
	memset(str, 0x00, sizeof(str));


	//WiringPi Init
#ifdef USES_BCM_NUMBERING
	wiringPiSetupGpio();													/* use the gpio pin numbers from the BCM MCU			*/
#else
	wiringPiSetup();														/* use the gpio pin numbers from the WiringPi API		*/
#endif


	//******************************************************************************************************************************//
	//													GPIO INPUT INIT																//
	// @config	Input, Pullup Active																								//
	//******************************************************************************************************************************//
	pinMode(INPUT_PIN_NUM, INPUT);
	pullUpDnControl(INPUT_PIN_NUM, PUD_UP);									/* idle-high											*/

	//ISR
	wiringPiISR(INPUT_PIN_NUM, INT_EDGE_BOTH, &isr_gpio);					/* ISR Configure 										*/


	//******************************************************************************************************************************//
	//													GPIO OUTPUT INIT															//
	// @config	Input, Pullup Active																								//
	//******************************************************************************************************************************//
	pinMode(OUTPUT_PIN_NUM, OUTPUT);
	digitalWrite(OUTPUT_PIN_NUM, 0);										/* off-low												*/



	return;
}


/************************************************************************************************************************************/
/**	@fcn		void isr_gpio(void)
 *  @brief		interrupt service routine for gpio peripheral
 *
 *  @hazard		there is no way to clear interrupts in the Raspberry Pi SDK, so this may fire multiple times on a single GPIO action!
 */
/************************************************************************************************************************************/
void isr_gpio(void) {

	eventCt++;

	printf("Edge Detected on GPIO\n");

	delayMs(50);															/* let wvfm edge stabilize before exit					*/

	return;
}


/************************************************************************************************************************************/
/**	@fcn		void delayMs(uint32_t delay_ms)
 *  @brief		simple extension of delay loop into milliseconds
 */
/************************************************************************************************************************************/
void delayMs(uint32_t delay_ms) {

	uint32_t delay_us = delay_ms * 1000;

	delayMicroseconds(delay_us);
}
