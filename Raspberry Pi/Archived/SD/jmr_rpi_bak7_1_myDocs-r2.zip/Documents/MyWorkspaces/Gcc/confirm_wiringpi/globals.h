#ifndef GLOBALS_H_
#define GLOBALS_H_

//System Config
#define USES_WPI_NUMBERING												/* for the GPIO pins (e.g. GPIO0)							*/
//#define USES_BCM_NUMBERING													/* for the GPIO pins (e.g. GPIO17)							*/


//Libraries
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>


//WiringPi
#include <wiringPi/wiringPi.h>


//Locals
void sys_init(void);
void flashDemo(void);
void isr_gpio(void);
void delayMs(uint32_t delay_ms);


//defs
#ifdef USES_BCM_NUMBERING
	#define INPUT_PIN_NUM		(17)										/* BCM17												*/
	#define OUTPUT_PIN_NUM		(18)										/* BCM18												*/
#else
	#define INPUT_PIN_NUM		(0)											/* GPIO0												*/
	#define OUTPUT_PIN_NUM		(1)											/* GPIO1												*/
#endif

//Vars
const uint32_t FLASHDELAY_MS = 1000;


#endif /* GLOBALS_H_ */
