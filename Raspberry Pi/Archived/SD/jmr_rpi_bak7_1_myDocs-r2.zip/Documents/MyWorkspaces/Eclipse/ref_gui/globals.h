#ifndef GLOBALS_H_
#define GLOBALS_H_

//Libraries
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

//GTK
#include <gtk/gtk.h>
#include <glib/gmain.h>
#include <glib.h>															/* ? 													*/
#include <cairo.h>

//Locals
bool time_handler(GtkWidget *widget);
bool on_expose_event(GtkWidget *widget, GdkEventExpose *event, void *data);



#endif /* GLOBALS_H_ */

