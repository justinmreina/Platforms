/************************************************************************************************************************************/
/** @file		main.c
 * 	@brief		reference gtk gui examples from Zet Code GTK+
 * 	@source		http://zetcode.com/gui/gtk2/firstprograms/
 *
 * 	@author		Justin Reina, Firmware Engineer, Misc. Company
 * 	@created	2/19/17
 * 	@last rev	2/19/17
 *
 *  @section	Pkg-Config
 *  	add the following to Compilation, Linkage and Assembler use
 *  		"`pkg-config --cflags gtk+-3.0` `pkg-config --libs gtk+-3.0`"
 *
 * 	@section	Opens
 * 			clear "expose-event is invalid for GtkDrawingArea" warning
 */
/************************************************************************************************************************************/
#include "globals.h"

char buf[256];

//GUI Components
GtkWidget *window;
GtkWidget *darea;

int main(int argc, char *argv[]) {

	printf("!!!Hello World!!!\n"); 											/* prints !!!Hello World!!! 							*/

	gtk_init(&argc, &argv);

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

	darea = gtk_drawing_area_new();
	gtk_container_add(GTK_CONTAINER(window), darea);

	g_signal_connect(G_OBJECT(darea), "expose-event", G_CALLBACK(on_expose_event), NULL);
	g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

	gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
	gtk_window_set_default_size(GTK_WINDOW(window), 300, 200);

	gtk_window_set_title(GTK_WINDOW(window), "Timer");
	g_timeout_add(1000, (GSourceFunc) time_handler, (void *) window);

	gtk_widget_show_all(window);
	time_handler(window);

	gtk_main();

  	printf("Demo Complete\n");

	return EXIT_SUCCESS;
}


bool on_expose_event(GtkWidget *widget, GdkEventExpose *event, void *data) {

	printf("on_expose_event called\n");

  cairo_t *cr;

  GdkWindow *window = gtk_widget_get_window(widget);

  cr = gdk_cairo_create(window);

  cairo_move_to(cr, 30, 30);
  cairo_set_font_size(cr, 15);
  cairo_show_text(cr, buf);

  cairo_destroy(cr);

  return false;
}


bool time_handler(GtkWidget *widget) {

	GdkWindow *window = gtk_widget_get_window(widget);
	if(window == NULL) {
		printf("window was null, exiting now...\n");
		return false;
	}

	GDateTime *now = g_date_time_new_now_local();
	char *my_time = g_date_time_format(now, "%H:%M:%S");

	sprintf(buf, "%s\n", my_time);
	printf(buf);

  gtk_widget_queue_draw(widget);

  return true;
}
