#ifndef CORE_TIME_H_
#define CORE_TIME_H_

//Libraries
#include <stdio.h>
#include <stdint.h>
#include <time.h>

//Project
#include "log.h"


//Globals
extern void os_timer_init(void);
extern void os_time_getLocal(char *dest, uint32_t dest_size);

//Locals
void os_timer_getTime(struct timespec *time);
void os_timer_printCurrTime(void);


#endif /* CORE_TIME_H_ */

