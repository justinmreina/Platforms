#include "log.h"


FILE *os_logFile = NULL;


void os_log_init(void) {

    char fullFilePath[100] = {0};

    strcpy(fullFilePath, "./");                                             /* current directory                                    */
    strcpy(fullFilePath, PROJ_NAME);                                        /* project name                                         */
    strcat(fullFilePath, ".log");                                           /* log file                                             */

    os_logFile = fopen(fullFilePath, "w");
    os_log_write("os", "log file initialized", LOG_CODE_OK);

    return;
}


/************************************************************************************************************************************/
/** @fcn       void os_log_write(char *source, char *message, uint32_t status_code)
 *  @brief     write a line to the log file, appending a EOL ('\n')
 *
 *  @param [in] (char*) source - the author or source of this log message, written to the lov
 *  @param [in] (char*) message - message to write to the log
 *  @param [in] (char*) status_code - status code as found in log.h
 *
 *  @pre    log file is initialized
 *
 *  @section    Format
 *      source [date] "message" status-code
 *
 *  @section    Example
 *      local [10/Oct/1999:21:15:05 +0500] "cannot see user 1.2.3.4" 0
 */
/************************************************************************************************************************************/
void os_log_write(char *source, char *message, uint32_t status_code) {

    char   dateStr[50] = {0};
    char   codeStr[50] = {0};
    char   logStr[100] = {0};

    //Safety
    if(os_logFile == NULL) {
        perror("error attempting to write to log file which is not initialized, aborting");
    }

    //Format Vars to String
    os_time_getLocal(dateStr, 80);
    sprintf(codeStr, "%d", status_code);

    //Gen Log Line
    strcat(logStr, source);     //source
    strcat(logStr, "\t[");

    strcat(logStr, dateStr);    //[date]
    strcat(logStr, "] \"");

    strcat(logStr, message);    //"message"
    strcat(logStr, "\" ");

    strcat(logStr, codeStr);    //status-code
    strcat(logStr, " ");

    //Write
    fprintf(os_logFile, logStr);
    fprintf(os_logFile, "\n");

    return;
}


/************************************************************************************************************************************/
/** @fcn       void os_log_get(char *dest)
 *  @brief     read the logfile
 *  @note   not implemented yet
 *
 *  @param [in] (char*) dest - location to store the log file contents
 *
 *  @pre    log file is initialized
 */
/************************************************************************************************************************************/
void os_log_get(char *dest) {
    for(;;);
}


/************************************************************************************************************************************/
/** @fcn    void os_log_set_bluetooth_logging(void)
 *  @brief  write all bluetooth comm to log as well
 *  @note   not implemented yet
 *
 *  @note   this only covers to log, bluetooth can consider doing it's own log too
 *
 *  @pre    log file is initialized
 */
/************************************************************************************************************************************/
void os_log_set_bluetooth_logging(void) {
    for(;;);
}


/************************************************************************************************************************************/
/** @fcn    void os_log_close(void)
 *  @brief  close the log file
 *
 *  @pre    log file is initialized
 *  @post   log file is closed
 */
/************************************************************************************************************************************/
void os_log_close(void) {

    //Safety
    if(os_logFile == NULL) {
        perror("error attempting to close log file which is not initialized, aborting");
    }

    os_log_write("os", "Log file closed", LOG_CODE_OK);

    fclose(os_logFile);

    return;
}


/************************************************************************************************************************************/
/** @fcn    void logDemo(void)
 *  @brief  do a log file demo
 *
 *  @pre    log file is initialized
 */
/************************************************************************************************************************************/
void logDemo(void) {

    os_log_write("gym", "A", LOG_CODE_OK);
    os_log_write("gym", "B", LOG_CODE_OK);
    os_log_write("MySrc", "MyMsg", LOG_CODE_ERR);
    os_log_write("gym", "C-ish", LOG_CODE_OK);

    return;
}

