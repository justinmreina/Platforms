/************************************************************************************************************************************/
/** @file       main.c
 *  @brief      a template project to get started from
 *  @details    x
 *
 *  @target     Broadcom BCM2837
 *  @board      Raspberry Pi 3 - Model B V1.2
 *
 *  @author     Justin Reina, Firmware Engineer, Misc. Company
 *  @created    1/31/17
 *  @last rev   1/31/17
 *
 *  @section    Opens
 *          x
 */
/************************************************************************************************************************************/
#include "globals.h"

//Globals
char str[100];                                                          /* general buffer for sprintf gen                           */


/************************************************************************************************************************************/
/** @fcn        int main(void)
 *  @brief      illustration of wiringPi use, for I and O
 */
/************************************************************************************************************************************/
int main(void) {

    sys_init();

    logDemo();

    mailDemo();

    bluetoothDemo();

    flashDemo();

    sys_close();

    return EXIT_SUCCESS;
}



/************************************************************************************************************************************/
/** @fcn        void bluetoothDemo(void)
 *  @brief      shows bluetooth libraries in use
 */
/************************************************************************************************************************************/
void bluetoothDemo(void) {

    printf("Raspberry Pi bluetooth demo\n");

    inquiry_info *ii = NULL;
    int max_rsp, num_rsp;
    int dev_id, sock, len, flags;
    int i;
    char addr[19] = { 0 };
    char name[248] = { 0 };

    printf("\nopening route and dev\n");

    dev_id = hci_get_route(NULL);
    sock = hci_open_dev( dev_id );
    if (dev_id < 0 || sock < 0) {
        perror("opening socket");
        exit(1);
    }

    printf("preparing ii\n");

    len = 8;
    max_rsp = 255;
    flags = IREQ_CACHE_FLUSH;
    ii = (inquiry_info*)malloc(max_rsp * sizeof(inquiry_info));

    printf("performing hci inquiry\n");

    num_rsp = hci_inquiry(dev_id, len, max_rsp, NULL, &ii, flags);


    sprintf(str, "inquiry result: %u devices\n", num_rsp);
    printf(str);

    if(num_rsp<0) {
        perror("hci_inquiry");
    }

    for(i=0; i<num_rsp; i++) {

        ba2str(&(ii+i)->bdaddr, addr);

        memset(name, 0, sizeof(name));

        if(hci_read_remote_name(sock, &(ii+i)->bdaddr, sizeof(name), name, 0) < 0) {
            strcpy(name, "[unknown]");
        }

        printf("%s %s\n", addr, name);
    }

    printf("closing\n");
    free(ii);
    close(sock);
    printf("complete\n");

    return;
}


/************************************************************************************************************************************/
/** @fcn        void flashDemo(void)
 *  @brief      shows using wiringPi, confirms it is working!
 */
/************************************************************************************************************************************/
void flashDemo(void) {

    int i;

    printf("Raspberry Pi blink demo\n");

    for(i=0;i<10; i++) {
        printf("blink...\n");

        bool sw0 = digitalRead(PIN_SW);                                     /* read a switch                                        */

        sprintf(str, "SW: %x\n", sw0);
        printf(str);

        digitalWrite (PIN_LED, HIGH);                                       /* On                                                   */
        delay(FLASHDELAY_MS);                                               /* mS                                                   */

        digitalWrite(PIN_LED, LOW);                                         /* Off                                                  */
        delay(FLASHDELAY_MS);                                               /* mS                                                   */
    }
}


/************************************************************************************************************************************/
/** @fcn        void sys_init(void)
 *  @brief      initialize the system on boot
 *
 *  @pre        any
 *  @post       LEDs set to Output & Low, SWs set to Inputs w/Pullup
 */
/************************************************************************************************************************************/
void sys_init(void) {

    //-----------------------------------------------------------OS Init------------------------------------------------------------//
    os_log_init();
    os_timer_init();


    //----------------------------------------------------------GPIO Init-----------------------------------------------------------//
    wiringPiSetup();

    //pins
    pinMode(PIN_LED, OUTPUT);
    pinMode(PIN_SW, INPUT);

    //pull-up
    pullUpDnControl(PIN_SW, PUD_UP);                                        /* idle-high                                            */

    //init vals
    digitalWrite(PIN_LED, LOW);                                             /* Off                                                  */


    //--------------------------------------------------------Bluetooth Init--------------------------------------------------------//
    //(would go here, if desired)


    //----------------------------------------------------------App Init------------------------------------------------------------//
    //(put your stuff here)


    printf("system initialized\n");

    os_log_write("os", "System initialization complete", LOG_CODE_OK);

    return;
}


/************************************************************************************************************************************/
/** @fcn        void sys_close(void)
 *  @brief      close the system on completion
 *
 *  @pre        any
 *  @post       ready for close
 */
/************************************************************************************************************************************/
void sys_close(void) {

    printf("system closed");

    os_log_write("os", "System closed", LOG_CODE_OK);

    os_log_close();

    return;
}
