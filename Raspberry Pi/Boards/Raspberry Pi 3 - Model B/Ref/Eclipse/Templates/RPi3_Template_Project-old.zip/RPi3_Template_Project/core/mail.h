#ifndef CORE_MAIL_H_
#define CORE_MAIL_H_

//Libraries
#include <stdio.h>
#include <stdint.h>
#include <string.h>

//Project
#include "log.h"

//Typedefs
typedef struct message {
    int a;
    int b;
} Message;


//Defs
#define MAILBOX_SIZE        (3)                                               /* pick as needed                                   */


//Globals
extern void os_mail_init(void);
extern void os_mail_clean(void);
extern int os_mail_getCount(void);
extern int os_mail_getCount(void);
extern Message* os_mail_get(void);
extern void os_mail_put(Message *msg);
extern void mailDemo(void) ;


#endif /* CORE_MAIL_H_ */

