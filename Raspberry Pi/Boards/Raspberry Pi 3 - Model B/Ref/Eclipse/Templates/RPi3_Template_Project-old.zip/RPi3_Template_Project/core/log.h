#ifndef CORE_LOG_H_
#define CORE_LOG_H_

//Libraries
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

//Project
#include "../globals.h"
#include "time.h"


//Globals
extern void os_log_init(void);
extern void os_log_write(char *source, char *message, uint32_t status_code);
extern void os_log_get(char *dest);
extern void os_log_close(void);
extern void logDemo(void);


//Definitions (note - add your own log code's here as needed)
#define LOG_CODE_OK     (0)
#define LOG_CODE_ERR    (1)
#define LOG_CODE_WARN   (2)


#endif /* CORE_LOG_H_ */
