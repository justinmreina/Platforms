/**
 *  @note	this is a simple template mailbox, used for copying over to your own mailbox uses
 */
#include "mail.h"

//Globals
char mail_str[100];

//Mailbox
Message mailbox[MAILBOX_SIZE];

uint32_t mailbox_head;                                                       /* address of current message to read                  */
uint32_t mailbox_tail;                                                       /* address of current message to write                 */

uint32_t mailbox_ct;


/************************************************************************************************************************************/
/** @fcn        void os_mail_init(void)
 *  @brief      x
 */
/************************************************************************************************************************************/
void os_mail_init(void) {

    //empty and clean
    mailbox_head = 0;
    mailbox_tail = 0;
    mailbox_ct   = 0;

    memset(mailbox, 0x00, sizeof(mailbox));

    os_log_write("mail", "mailbox initialized and clean", LOG_CODE_OK);

    return;
}


/************************************************************************************************************************************/
/** @fcn        int os_mail_getCount(void)
 *  @brief      x
 *
 *  @param [out] (int) number of new messages pending
 */
/************************************************************************************************************************************/
int os_mail_getCount(void) {

    return mailbox_ct;
}


/************************************************************************************************************************************/
/** @fcn        Message* os_mail_get(void)
 *  @brief      get the next message and update mailbox
 *
 *  @param [out] (Message*) next message
 *
 *  @note   returns null if empty
 */
/************************************************************************************************************************************/
Message* os_mail_get(void) {

    //Safety
    if(mailbox_ct == 0) {
        return NULL;
    }

    Message *nextMessage = &mailbox[mailbox_head];

    //Update Head & Count
    mailbox_head = (mailbox_head+1) % MAILBOX_SIZE;
    mailbox_ct--;

    return nextMessage;
}

/************************************************************************************************************************************/
/** @fcn        void os_mail_put(Message *msg)
 *  @brief      x
 *
 *  @param [in] (Message*) msg - new message
 */
/************************************************************************************************************************************/
void os_mail_put(Message *msg) {

    //Safety
    if(mailbox_ct >= MAILBOX_SIZE) {
        perror("Attempted to write to a full mailbox\n");
        return;
    }

    //Get Ref
    Message *newMessage = &mailbox[mailbox_tail];

    //Store new message
    newMessage->a = msg->a;
    newMessage->b = msg->b;

    //Update Tail & Count
    mailbox_tail = (mailbox_tail+1);
    mailbox_tail = mailbox_tail % MAILBOX_SIZE;
    mailbox_ct++;

    os_log_write("mail", "message written to mailbox", LOG_CODE_OK);

    return;
}


/************************************************************************************************************************************/
/** @fcn        void os_mail_clean(void)
 *  @brief      clean the mailvox
 */
/************************************************************************************************************************************/
void os_mail_clean(void) {
    os_mail_init();
    return;
}


/************************************************************************************************************************************/
/** @fcn        void mailDemo(void)
 *  @brief      show the mailbox in use
 *
 *  @pre os_mail_init was called
 */
/************************************************************************************************************************************/
void mailDemo(void) {

    int i;

    Message currMsg_send;
    Message *currMsg_get;

    for(i=0; i<10; i++) {

        currMsg_send.a = i;
        currMsg_send.b = 2*i + 1;

        sprintf(mail_str, "Sending '%d/%d'\n", currMsg_send.a, currMsg_send.b);
        printf(mail_str);

        os_mail_put(&currMsg_send);

        sprintf(mail_str, "->Mailbox Ct: %d\n", os_mail_getCount());
        printf(mail_str);

        currMsg_get = os_mail_get();

        sprintf(mail_str, "Got '%d/%d'\n", currMsg_get->a, currMsg_get->b);
        printf(mail_str);

        sprintf(mail_str, "->Mailbox Ct: %d\n\n", os_mail_getCount());
        printf(mail_str);
    }

    return;
}

