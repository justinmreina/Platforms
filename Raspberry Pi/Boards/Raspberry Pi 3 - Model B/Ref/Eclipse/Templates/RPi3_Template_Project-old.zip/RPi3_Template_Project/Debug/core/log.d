core/log.o: ../core/log.c ../core/log.h ../core/../globals.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/bluetooth.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/hci.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/hci_lib.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h \
 ../core/../core/log.h ../core/../core/time.h ../core/../core/log.h \
 ../core/../core/delay.h ../core/../core/mail.h ../core/time.h

../core/log.h:

../core/../globals.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/bluetooth.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/hci.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/hci_lib.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h:

../core/../core/log.h:

../core/../core/time.h:

../core/../core/log.h:

../core/../core/delay.h:

../core/../core/mail.h:

../core/time.h:
