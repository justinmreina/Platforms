#ifndef CORE_THREADS_H_
#define CORE_THREADS_H_


//Libraries
#include <stdio.h>
#include <string.h>
#include<pthread.h>


//Definitions
#define MAX_THREAD_COUNT        (100)


//Globals
extern void threads_init(void);
extern int thread_create(void *fcn, void *args);
extern pthread_t thread_getId(void);

//Locals
void printPthreadCreateResp(int err);


#endif /* CORE_THREADS_H_ */

