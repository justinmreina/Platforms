//<WARN: Has not yet been tested, use at your own risk!!>
#include "threads.h"

int activeThreadCt;                                                     /* number of active threads we have in place                */
pthread_t tid[MAX_THREAD_COUNT];                                        /* id's for each thread                                     */


/************************************************************************************************************************************/
/** @fcn      void threads_init(void)
 * @brief     initialize the thread api for use
 */
/************************************************************************************************************************************/
void threads_init(void) {
    printf("WARN: Has not yet been tested, use at your own risk!!\n");

    //Clear
    activeThreadCt = 0;
    memset(tid, 0x00, sizeof(tid));

    return;
}


/************************************************************************************************************************************/
/** @fcn      int thread_create(void *fcn, void *args)
 * @brief     create a new thread
 * @param [out] pthread id
 *
 */
/************************************************************************************************************************************/
int thread_create(void *fcn, void *args) {

    printf("WARN: Has not yet been tested, use at your own risk!!\n");

    int err;

    int newThreadInd = activeThreadCt;                                      /* if there are 2 active, we'll be sitting at 3, or [2] */

    err = pthread_create(&(tid[newThreadInd]), NULL, fcn, args);

    printPthreadCreateResp(err);

    if(err == 0) {
        activeThreadCt++;
    }

    return tid[newThreadInd];
}


/************************************************************************************************************************************/
/** @fcn      pthread_t thread_getId(void)
 * @brief     get id of current thread
 */
/************************************************************************************************************************************/
pthread_t thread_getId(void) {

    printf("WARN: Has not yet been tested, use at your own risk!!\n");

    pthread_t id = pthread_self();

    return id;
}


/************************************************************************************************************************************/
/** @fcn        void printPthreadCreateResp(int err)
 *  @brief      print generic response
 */
/************************************************************************************************************************************/
void printPthreadCreateResp(int err) {

    printf("WARN: Has not yet been tested, use at your own risk!!\n");

    if (err != 0) {
        printf("\ncan't create thread :[%s]", strerror(err));
    } else {
        printf("\nThread created successfully\n");
    }

    return;
}
