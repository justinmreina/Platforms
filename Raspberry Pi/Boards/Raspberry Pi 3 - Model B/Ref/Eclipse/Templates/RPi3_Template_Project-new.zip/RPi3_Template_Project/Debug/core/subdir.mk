################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../core/delay.c \
../core/log.c \
../core/mail.c \
../core/threads.c \
../core/time.c 

OBJS += \
./core/delay.o \
./core/log.o \
./core/mail.o \
./core/threads.o \
./core/time.o 

C_DEPS += \
./core/delay.d \
./core/log.d \
./core/mail.d \
./core/threads.d \
./core/time.d 


# Each subdirectory must supply rules for building sources it contributes
core/%.o: ../core/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Cross GCC Compiler'
	arm-linux-gnueabihf-gcc -I"M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib" -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<" -pthread
	@echo 'Finished building: $<'
	@echo ' '


