core/threads.o: ../core/threads.c ../core/threads.h

../core/threads.h:
