/************************************************************************************************************************************/
/** @file		main.c
 * 	@brief		show how GPIO is used
 * 	@details	x
 *
 *  @target		Broadcom BCM2837
 *	@board		Raspberry Pi 3 - Model B r1.2
 *
 * 	@author		Justin Reina, Firmware Engineer, Misc. Company
 * 	@created	1/19/17
 * 	@last rev	1/30/17
 *
 * 	@section	Opens
 * 			ISRs
 * 			PWM
 * 			Pin Grouping
 */
/************************************************************************************************************************************/
#include "globals.h"


//Globals
char str[100];															/* general buffer for sprintf gen							*/


/************************************************************************************************************************************/
/**	@fcn		int main(void)
 *  @brief		illustration of wiringPi use, for I and O
 */
/************************************************************************************************************************************/
int main(void) {

	sys_init();

	flashDemo();

	return EXIT_SUCCESS;
}


/************************************************************************************************************************************/
/**	@fcn		void flashDemo(void)
 *  @brief		shows using wiringPi, confirms it is working!
 */
/************************************************************************************************************************************/
void flashDemo(void) {

	printf("Raspberry Pi blink demo\n");

	for(;;) {
		printf("blink...\n");

		bool sw0 = digitalRead(PIN_SW);										/* read a switch										*/

		sprintf(str, "SW: %x\n", sw0);
		printf(str);

		digitalWrite (PIN_LED, HIGH);										/* On													*/
		delay(FLASHDELAY_MS);												/* mS													*/

		digitalWrite(PIN_LED, LOW);											/* Off													*/
		delay(FLASHDELAY_MS);												/* mS													*/
	}
}


/************************************************************************************************************************************/
/**	@fcn		void sys_init(void)
 *  @brief		initialize the system on boot
 *
 *  @pre		any
 *  @post		LEDs set to Output & Low, SWs set to Inputs w/Pullup
 */
/************************************************************************************************************************************/
void sys_init(void) {

    //-------------------------------------------------------Timer Init-------------------------------------------------------------//
    os_timer_init();


    //--------------------------------------------------------GPIO Init-------------------------------------------------------------//
	wiringPiSetup();

	//pins
	pinMode(PIN_LED, OUTPUT);
	pinMode(PIN_SW, INPUT);

	//pull-up
	pullUpDnControl(PIN_SW, PUD_UP);										/* idle-high											*/

	//init vals
	digitalWrite(PIN_LED, LOW);												/* Off													*/

	printf("system initialized");											/* prints Hello GPIO? 									*/

	return;
}

