#ifndef CORE_OS_H_
#define CORE_OS_H_

//Libraries
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>


//WiringPi
#include <wiringPi/wiringPi.h>

//Project
#include "time.h"

//Defs
#define MAX_NUM_OS_PROCS                (100)
#define MAX_NUMBER_OS_NAME_CHARS        (100)
#define MAILBOX_SIZE                    (100)

//Datatypes
typedef struct process {
    char name[MAX_NUMBER_OS_NAME_CHARS];
    void (*process)(bool terminate);
    void (*mailboxHandler)(void *message);
} Process;


//Globals
extern uint32_t os_procs_count;

extern void os_init(void);
extern bool os_isInitialized(void);

void os_addProc(char *name, void(*process)(bool), void(*mailHandler)(void*));
extern Process* os_getProc(char *name);
extern uint32_t os_getNumProcesses(void);

extern void os_remProc(char *name, bool kill);
extern void os_killProc(char *name);

extern void os_sendMsg(char *proc_name, void *message);

extern void os_loopDelay(void);
extern void os_setLoopDelay(uint32_t delay_ms);


//Timer
extern void os_timer_init(void);
void os_timer_getTime(struct timespec *time);
void os_timer_printCurrTime(void);


#endif /* CORE_OS_H_ */
