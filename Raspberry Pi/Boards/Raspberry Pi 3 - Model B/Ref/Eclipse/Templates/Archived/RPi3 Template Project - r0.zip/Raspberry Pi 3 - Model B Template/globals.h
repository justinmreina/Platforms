#ifndef GLOBALS_H_
#define GLOBALS_H_


//Libraries
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>


//WiringPi
#include <wiringPi/wiringPi.h>


//Project
#include "core/os.h"


//Locals
void sys_init(void);
void flashDemo(void);


//defs
#define	PIN_LED		(0)														/* GPIO0												*/
#define	PIN_SW		(2)														/* GPIO2												*/


//Vars
const uint32_t FLASHDELAY_MS = 2000;


#endif /* GLOBALS_H_ */
