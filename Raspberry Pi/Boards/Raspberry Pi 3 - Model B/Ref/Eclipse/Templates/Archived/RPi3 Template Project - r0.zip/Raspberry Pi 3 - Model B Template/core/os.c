/************************************************************************************************************************************/
/** @file		os.c
 * 	@brief		x
 * 	@details	x
 *
 *  @target		x
 *	@board		x
 *
 * 	@author		Justin Reina, Firmware Engineer, Misc. Company
 * 	@created	x
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			confirm memset in os_init works safely
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Misc. Product related source files are the explicit property of
 * 			Misc. Company. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
#include "os.h"


//Locals
struct timespec os_boot_time;
char buf[2048];


/************************************************************************************************************************************/
/** @fcn        void os_timer_init(void)
 *  @ref		http://www.raspberry-projects.com/pi/programming-in-c/timing/clock_gettime-for-acurate-timing
 *  
 *  @step1		add #include <time.h>
 *  @step2	 	add (Right click your project > Properties > C/C++ Build > Settings > Cygwin C++ Linker > Libraries.  Add a new library entry: rt)
 */
/************************************************************************************************************************************/
void os_timer_init(void) {

    struct timespec gettime;

	//get timer
    os_timer_getTime(&gettime);

	//store current time
    os_boot_time.tv_nsec = gettime.tv_nsec;
    os_boot_time.tv_sec  = gettime.tv_sec;

	return;
}


/************************************************************************************************************************************/
/** @fcn        void os_timer_getTime(struct timespec *time)
 *  @brief      grab the current os time to *time
 *  @param		[in] (timespec*) time - where to store the os time to
 */
/************************************************************************************************************************************/
void os_timer_getTime(struct timespec *time) {

    struct timespec currTime;

    //get time
    clock_gettime(CLOCK_REALTIME, &currTime);

    //calc delta
    uint64_t timediff_s  =  currTime.tv_sec - os_boot_time.tv_sec;
    uint64_t timediff_ns = currTime.tv_nsec - os_boot_time.tv_nsec;

    //store
    time->tv_sec  = timediff_s;
    time->tv_nsec = timediff_ns;

    return;
}


/************************************************************************************************************************************/
/** @fcn        void os_timer_printCurrTime(void)
 *  @brief      print the os time to the console with printf()
 */
/************************************************************************************************************************************/
void os_timer_printCurrTime(void) {

    struct timespec gettime;

    os_timer_getTime(&gettime);

    uint64_t time_s = gettime.tv_sec;
    uint64_t time_ns = gettime.tv_nsec;
    uint64_t timediff_total = (time_s * 1000000000) + time_ns;

    sprintf(buf, "timer is: %llu\n", timediff_total);
    printf(buf);

    return;
}

