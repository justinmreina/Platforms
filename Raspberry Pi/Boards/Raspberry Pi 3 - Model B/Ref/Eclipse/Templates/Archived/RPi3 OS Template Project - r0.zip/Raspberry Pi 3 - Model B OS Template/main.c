/************************************************************************************************************************************/
/** @file		main.c
 * 	@brief		provide template structure for jmr os implementation on RPi 3 Model B
 * 	@details	this is tricky with RPi given the high level of abstraction, and complexity underneath on this platform. The goal
 * 	            here is os preparation for VIEVU use, and code will be abstracted, simplified and targeted at this marker
 *
 *  @target		Broadcom BCM2837
 *	@board		Raspberry Pi 3 Model B r1.2
 *
 * 	@author		Justin Reina, Firmware Engineer, Misc. Company
 * 	@created	1/29/17
 * 	@last rev	1/29/17
 *
 *
 * 	@section	Opens
 * 			task delay between tasks
 * 			provides delayed routine calls
 * 			messaging & mailboxes
 * 			global tick counter
 *
 * 	@section    OS Fundamental Principles
 * 	        non pre-emptive
 * 	        non blocking
 * 	        a series of processes
 * 	        provides delayed routine calls
 *          provides a clean interface to the user to add, remove, get, kill or message processes
 *          provides mailboxes to send tasks messages
 *          has a global tick timer always running
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Misc. Product related source files are the explicit property of
 * 			Misc. Company. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
#include "globals.h"
#include "test/test_mailbox.h"


/************************************************************************************************************************************/
/**	@fcn		int main(void)
 *  @brief		x
 */
/************************************************************************************************************************************/
int main(void) {

    int ind_active_proc = 0;                                                /* index of the active process for os                   */

    //Init System
    sys_init();

    //Run OS
    for(;;) {
        //Get
        Process *proc = os_getProc(procNames[ind_active_proc]);

        //Run
        proc->process(false);

        //Update Index
        ind_active_proc = (ind_active_proc+1) % os_procs_count;

        //Delay
        os_loopDelay();
    }

    return EXIT_SUCCESS;
}


/************************************************************************************************************************************/
/** @fcn        int sys_init(void)
 *  @brief      initialize the system and os
 *
 *  @post       os has active processes and is ready to run
 *
 *  @hazard     does not exit until processes are present in os to run
 */
/************************************************************************************************************************************/
int sys_init(void) {

    os_init();

    //<load & init your processes here>

    //nice look 'n feel
    os_setLoopDelay(500);

    //Safety (wait for processes present)
    while(os_getNumProcesses() == 0) {
        delayMs(1);                                                         /* delay 1ms                                            */
    }

    return EXIT_SUCCESS;
}
