#ifndef CORE_TIME_H_
#define CORE_TIME_H_

//Libraries
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//WiringPi
#include <wiringPi/wiringPi.h>

//Globals
extern void delayS(uint32_t delayS);
extern void delayMs(uint32_t delayMs);
extern void delayUs(uint32_t delayUs);


#endif /* CORE_TIME_H_ */

