/************************************************************************************************************************************/
/** @file		os.c
 * 	@brief		x
 * 	@details	x
 *
 *  @target		x
 *	@board		x
 *
 * 	@author		Justin Reina, Firmware Engineer, Misc. Company
 * 	@created	x
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			confirm memset in os_init works safely
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Misc. Product related source files are the explicit property of
 * 			Misc. Company. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
#include "os.h"


//Locals
uint32_t os_loopDelayValue_ms;
uint32_t os_procs_count = UINT32_MAX;                                       /* UINT32_MAX denotes non-initialization                */
Process os_procs[MAX_NUM_OS_PROCS];
struct timespec os_boot_time;

char buf[2048];


/************************************************************************************************************************************/
/** @fcn        void os_init(void)
 *  @brief      x
 */
/************************************************************************************************************************************/
void os_init(void) {

    //init as empty
    os_procs_count = 0;
    os_loopDelayValue_ms = 0;
    memset(os_procs, 0x00, sizeof(os_procs));

    //init timer
    os_timer_init();

    return;
}


/************************************************************************************************************************************/
/** @fcn        void os_init(void)
 *  @brief      as long as it is not the initial value it is in operation
 */
/************************************************************************************************************************************/
bool os_isInitialized(void) {
    return (os_procs_count != UINT32_MAX);
}


/************************************************************************************************************************************/
/** @fcn        void os_addProc(char *name, void(*process)(bool), void(*mailHandler)(void*))
 *  @brief      x
 *
 *  @param [in] (char*) name - process name
 *  @param [in] void(*process)(bool) - process routine to call for process operation
 *
 *  @note       written verbosely intentionally for clarity
 */
/************************************************************************************************************************************/
void os_addProc(char *name, void(*process)(bool), void(*mailHandler)(void*)) {

    int newProcIndex = os_procs_count;                                      /* goes at 'N', e.g. if size is '2', next goes to [2]   */

    os_procs_count++;                                                       /* update to reflect addition                           */

    Process *newProc = &os_procs[newProcIndex];

    //Store
    strcpy(newProc->name, name);
    newProc->process = process;
    newProc->mailboxHandler = mailHandler;

    return;
}


/************************************************************************************************************************************/
/** @fcn        void os_remProc(char *name, bool kill)
 *  @brief      remove a process from the os
 *
 *  @note       assumes all processes have unique names
 *
 *  @hazard     spins if process not found
 */
/************************************************************************************************************************************/
void os_remProc(char *name, bool kill) {

    int i, j;

    //Find it!
    for(i=0; i<MAX_NUM_OS_PROCS; i++) {

        Process *currProc = &os_procs[i];

        char *currName = currProc->name;

        //This it?
        if(strcmp(currName, name) == 0) {                                   /* strcmp returns 0 when matching                       */

            //kill if asked
            if(kill) {
                os_procs[i].process(true);                                  /* kill it                                              */
            }

            //remove by taking everyone past it and moving ahead
            for(j=i; j < os_procs_count; j++) {
                if(j < MAX_NUM_OS_PROCS){                                   /* if less than end                                     */
                    strcpy(os_procs[j].name, os_procs[j+1].name);
                    os_procs[j].process = os_procs[j+1].process;
                }
            }

            os_procs_count--;                                               /* now one less                                         */
            return;                                                         /* return on completion                                 */
        }
    }

    //if got this far it was not found, spin
    for(;;);

    return;                                                                 /* quiet the dang compiler...                           */
}


/************************************************************************************************************************************/
/** @fcn        void os_getProc(void)
 *  @brief      get a task, by name
 *
 *  @hazard     spins if task not found
 */
/************************************************************************************************************************************/
Process* os_getProc(char *name) {

    int i;

    //Find it!
    for(i=0; i<MAX_NUM_OS_PROCS; i++) {

        Process *currProc = &os_procs[i];

        char *currName = currProc->name;

        //This it?
        if(strcmp(currName, name) == 0) {                                   /*strcmp returns 0 when matching                        */
            return &os_procs[i];
        }
    }

    //if got this far it was not found, spin
    for(;;);

    return 0;                                                               /* quiet the dang compiler...                           */
}


/************************************************************************************************************************************/
/** @fcn        void os_sendMsg(char *proc_name, void *message)
 *  @brief      x
 *
 *  @section    Theory
 *      Add the message pointer to the process of 'proc_name's' mailbox. the data-type of message is not provided and assumed of
 *      knowledge by the process (e.g. a struct, maybe an int)
 *
 *  @hazard     spins if message is sent to a full mailbox
 */
/************************************************************************************************************************************/
void os_sendMsg(char *proc_name, void *message) {

    //Get the process
    Process *proc = os_getProc(proc_name);

    //Store new message
    proc->mailboxHandler(message);

    return;
}


/************************************************************************************************************************************/
/** @fcn        void os_loopDelay(void)
 *  @brief      delay after each run process
 */
/************************************************************************************************************************************/
void os_loopDelay(void) {

  delayMs(os_loopDelayValue_ms);

  return;
}


/************************************************************************************************************************************/
/** @fcn        void os_setLoopDelay(uint32_t delay_ms)
 *  @brief      set delay (s+ms+us)
 */
/************************************************************************************************************************************/
void os_setLoopDelay(uint32_t delay_ms) {
    os_loopDelayValue_ms = delay_ms;
    return;
}


/************************************************************************************************************************************/
/** @fcn        void os_timer_init(void)
 *  @ref		http://www.raspberry-projects.com/pi/programming-in-c/timing/clock_gettime-for-acurate-timing
 *  
 *  @step1		add #include <time.h>
 *  @step2	 	add (Right click your project > Properties > C/C++ Build > Settings > Cygwin C++ Linker > Libraries.  Add a new library entry: rt)
 */
/************************************************************************************************************************************/
void os_timer_init(void) {

    struct timespec gettime;

	//get timer
    os_timer_getTime(&gettime);

	//store current time
    os_boot_time.tv_nsec = gettime.tv_nsec;
    os_boot_time.tv_sec  = gettime.tv_sec;

	return;
}


/************************************************************************************************************************************/
/** @fcn        void os_timer_getTime(struct timespec *time)
 *  @brief      grab the current os time to *time
 *  @param		[in] (timespec*) time - where to store the os time to
 */
/************************************************************************************************************************************/
void os_timer_getTime(struct timespec *time) {

    struct timespec currTime;

    //get time
    clock_gettime(CLOCK_REALTIME, &currTime);

    //calc delta
    uint64_t timediff_s  =  currTime.tv_sec - os_boot_time.tv_sec;
    uint64_t timediff_ns = currTime.tv_nsec - os_boot_time.tv_nsec;

    //store
    time->tv_sec  = timediff_s;
    time->tv_nsec = timediff_ns;

    return;
}


/************************************************************************************************************************************/
/** @fcn        void os_timer_printCurrTime(void)
 *  @brief      print the os time to the console with printf()
 */
/************************************************************************************************************************************/
void os_timer_printCurrTime(void) {

    struct timespec gettime;

    os_timer_getTime(&gettime);

    uint64_t time_s = gettime.tv_sec;
    uint64_t time_ns = gettime.tv_nsec;
    uint64_t timediff_total = (time_s * 1000000000) + time_ns;

    sprintf(buf, "timer is: %llu\n", timediff_total);
    printf(buf);

    return;
}



/************************************************************************************************************************************/
/** @fcn        uint32_t os_getNumProcesses(void)
 *  @brief      return present process count
 *
 *  @param  [out] uint32_t      number of processes
 */
/************************************************************************************************************************************/
uint32_t os_getNumProcesses(void) {
    return os_procs_count;
}

