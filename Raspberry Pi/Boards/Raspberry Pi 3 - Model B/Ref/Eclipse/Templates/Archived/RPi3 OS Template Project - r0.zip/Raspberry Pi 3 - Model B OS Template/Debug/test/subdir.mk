################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../test/test_addProc.c \
../test/test_mailbox.c 

OBJS += \
./test/test_addProc.o \
./test/test_mailbox.o 

C_DEPS += \
./test/test_addProc.d \
./test/test_mailbox.d 


# Each subdirectory must supply rules for building sources it contributes
test/%.o: ../test/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Cross GCC Compiler'
	arm-linux-gnueabihf-gcc -I"M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib" -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


