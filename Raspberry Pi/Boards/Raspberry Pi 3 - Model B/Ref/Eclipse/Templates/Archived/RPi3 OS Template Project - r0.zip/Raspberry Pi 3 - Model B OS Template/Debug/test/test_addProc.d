test/test_addProc.o: ../test/test_addProc.c ../test/test_addProc.h \
 ../test/../globals.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h \
 ../test/../core/os.h ../test/../core/time.h

../test/test_addProc.h:

../test/../globals.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h:

../test/../core/os.h:

../test/../core/time.h:
