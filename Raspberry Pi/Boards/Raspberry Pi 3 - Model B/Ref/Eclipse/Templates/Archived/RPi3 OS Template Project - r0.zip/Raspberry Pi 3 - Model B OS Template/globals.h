#ifndef _GLOBALS_H_
#define _GLOBALS_H_


//Libraries
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


//WiringPi
#include <wiringPi/wiringPi.h>


//Project
#include "core/os.h"


//Defs


//Locals
int sys_init(void);


//Local Vars


#endif /* _GLOBALS_H_ */

