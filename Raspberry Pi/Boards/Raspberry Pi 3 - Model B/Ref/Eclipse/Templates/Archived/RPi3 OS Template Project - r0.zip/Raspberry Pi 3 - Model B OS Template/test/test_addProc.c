#include "test_addProc.h"


char *procNames2[4] = {"Task 1", "Task 2", "Task 4", "Task 5"};

char* name1 = "Task 1";
char* name2 = "Task 2";
char* name3 = "Task 3";
char* name4 = "Task 4";
char* name5 = "Task 5";
void task1(bool terminate);
void task2(bool terminate);
void task3(bool terminate);
void task4(bool terminate);
void task5(bool terminate);

char buf[2048];

//@pre      os_init() has been called
//@brief    tests addProc, getProc and remProc
void test_addProc(void) {

    //Gen Three Procs & Add Them
    os_addProc(name1, task1, NULL);
    os_addProc(name2, task2, NULL);
    os_addProc(name3, task3, NULL);
    os_addProc(name4, task4, NULL);
    os_addProc(name5, task5, NULL);

    //Get Them
    Process *p1 = os_getProc(name1);
    Process *p2 = os_getProc(name2);
    Process *p3 = os_getProc(name3);
    Process *p4 = os_getProc(name4);
    Process *p5 = os_getProc(name5);
    //Process *p6 = os_getProc("err");                                      /* this should hang                                     */


    //Print their names
    sprintf(buf, "Task 1 Name is '%s'\n", p1->name);
    printf(buf);
    sprintf(buf, "Task 2 Name is '%s'\n", p2->name);
    printf(buf);
    sprintf(buf, "Task 3 Name is '%s'\n", p3->name);
    printf(buf);
    sprintf(buf, "Task 4 Name is '%s'\n", p4->name);
    printf(buf);
    sprintf(buf, "Task 5 Name is '%s'\n", p5->name);
    printf(buf);

    //Call their routines
    p1->process(false);
    p2->process(false);
    p3->process(false);
    p4->process(false);
    p5->process(false);

    //Remove #3 and confirm #4 and #5 move
    os_remProc(name3, true);


    printf("\n");
    printf("//---------------------PROCESS 2 REMOVED-----------------------//\n");
    printf("\n");

    //Get Them
    p1 = os_getProc(name1);
    p2 = os_getProc(name2);
    p3 = os_getProc(name4);
    p4 = os_getProc(name5);
    //p5 = os_getProc(name5);   /*!!!<todo>!!!                              /* this should hang now too                             */
    //Process *p6 = os_getProc("err");                                      /* this should hang                                     */

    //Print their names
    sprintf(buf, "Task 1 Name now is '%s'\n", p1->name);
    printf(buf);
    sprintf(buf, "Task 2 Name now is '%s'\n", p2->name);
    printf(buf);
    sprintf(buf, "Task 3 Name now is '%s'\n", p3->name);
    printf(buf);
    sprintf(buf, "Task 4 Name now is '%s'\n", p4->name);
    printf(buf);

    //Call their routines
    p1->process(false);
    p2->process(false);
    p3->process(false);
    p4->process(false);

    return;
}

void task1(bool terminate) {
    printf("Hello Task 1\n");
    return;
}

void task2(bool terminate) {
    printf("Hello Task 2\n");
    return;
}

void task3(bool terminate) {

    if(terminate) {
        printf("  Killing Task 3\n");
    } else {
        printf("  Not Killing Task 3\n");
    }

    printf("Hello Task 3\n");

    return;
}

void task4(bool terminate) {
    printf("Hello Task 4\n");
    return;
}

void task5(bool terminate) {
    printf("Hello Task 5\n");
    return;
}

