#include "time.h"


void delayS(uint32_t delayS) {

    uint32_t delayMs = delayS*1000;
    uint32_t delayUs = delayMs*1000;
    delayMicroseconds(delayUs);

    return;
}


void delayMs(uint32_t delayMs) {

    uint32_t delayUs = delayMs*1000;
    delayMicroseconds(delayUs);

    return;
}


void delayUs(uint32_t delayUs) {

    delayMicroseconds(delayUs);

    return;
}
