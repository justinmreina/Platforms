/*
 * test_mailbox.h
 *
 *  Created on: Jan 29, 2017
 *      Author: Owner
 */

#ifndef TEST_TEST_MAILBOX_H_
#define TEST_TEST_MAILBOX_H_

//Project
#include "../globals.h"


//Datatypes
typedef struct mailTest_msg {
    char name[100];
    char food[100];
    int  age;
} MailTest_Msg;

//Globals
extern void test_mailbox_init(void);

char *procNames[3];


#endif /* TEST_TEST_MAILBOX_H_ */
