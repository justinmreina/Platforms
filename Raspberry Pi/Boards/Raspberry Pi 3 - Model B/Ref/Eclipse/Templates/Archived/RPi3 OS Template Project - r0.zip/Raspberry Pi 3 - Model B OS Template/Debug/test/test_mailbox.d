test/test_mailbox.o: ../test/test_mailbox.c ../test/test_mailbox.h \
 ../test/../globals.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h \
 ../test/../core/os.h ../test/../core/time.h

../test/test_mailbox.h:

../test/../globals.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h:

../test/../core/os.h:

../test/../core/time.h:
