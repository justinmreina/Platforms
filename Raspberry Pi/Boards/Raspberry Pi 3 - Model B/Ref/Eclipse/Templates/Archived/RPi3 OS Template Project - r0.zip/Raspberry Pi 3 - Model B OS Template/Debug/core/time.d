core/time.o: ../core/time.c ../core/time.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h

../core/time.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h:
