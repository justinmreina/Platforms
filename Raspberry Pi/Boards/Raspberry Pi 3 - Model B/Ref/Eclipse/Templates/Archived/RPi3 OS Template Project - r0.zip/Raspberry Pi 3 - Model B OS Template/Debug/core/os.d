core/os.o: ../core/os.c ../core/os.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h \
 ../core/time.h

../core/os.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h:

../core/time.h:
