#include "test_mailbox.h"

char *procNames[3] = {"sam", "jim", "art"};

char *proc_name1 = "sam";
char *proc_name2 = "jim";
char *proc_name3 = "art";

void process1(bool terminate);
void process2(bool terminate);
void process3(bool terminate);

void process1_mailboxHandler(void *message);
void process2_mailboxHandler(void *message);
void process3_mailboxHandler(void *message);


MailTest_Msg proc2_msg;
bool proc2_hasMsg;

MailTest_Msg proc3_msg;
bool proc3_hasMsg;



// pre: os_init() was called
// load up three tasks, which volley messages to each other, incrementing the num in struct by one and changing the name, leaving
// the gender string the same (A->B->C->A)
void test_mailbox_init(void) {

    //vars init
    memset(&proc2_msg, 0x00, sizeof(proc2_msg));
    proc2_hasMsg = false;
    memset(&proc3_msg, 0x00, sizeof(proc3_msg));
    proc3_hasMsg = false;

    //procs init
    os_addProc(proc_name1, process1, process1_mailboxHandler);
    os_addProc(proc_name2, process2, process2_mailboxHandler);
    os_addProc(proc_name3, process3, process3_mailboxHandler);

    //message start
    MailTest_Msg newMsg;

    strcpy(newMsg.name, "Bobby\n");
    strcpy(newMsg.food, "Apples\n");
    newMsg.age = 12;

    //<Step 1> Init - send a starting message to process1
    os_sendMsg(proc_name1, &newMsg);                                        /* this here begins the message volleying               */

    return;
}



void process1(bool terminate) {
    printf(">>Process 1 - Enter\n");
    printf(">>Process 1 - Exit\n");
    return;
}

//<Step 4> Grab message and pass along to process3-mailbox-handler
void process2(bool terminate) {

    printf(">>Process 2 - Enter\n");

    if(proc2_hasMsg == true) {

        printf(">>Process 2 - Proc Msg\n");
        MailTest_Msg *msg = &proc2_msg;

        char *name = msg->name;
        char *food = msg->food;
        int age = msg->age;

        MailTest_Msg newMsg;
        strcpy(newMsg.name, name);
        strcpy(newMsg.food, food);
        newMsg.age = age+1;

        os_sendMsg(proc_name3, &newMsg);

        //clear
        proc2_hasMsg = false;
    }
    printf(">>Process 2 - Exit\n");

    return;
}


//<Step 6>  Grab message and pass along to process1-mailbox-handler (loop and restart!!)
void process3(bool terminate) {

    printf(">>Process 3 - Enter\n");

    if(proc3_hasMsg == true) {
        MailTest_Msg *msg = &proc3_msg;

        char *name = msg->name;
        char *food = msg->food;
        int age = msg->age;

        MailTest_Msg newMsg;
        strcpy(newMsg.name, name);
        strcpy(newMsg.food, food);
        newMsg.age = age+1;

        os_sendMsg(proc_name1, &newMsg);

        //clear
        proc2_hasMsg = false;
    }

    printf(">>Process 3 - Exit\n");

    return;
}

//<Step 2> Grab message and pass along to process2-mailbox-handler
void process1_mailboxHandler(void *message) {

    printf("-->Process 1 Mailbox - Enter\n");

    MailTest_Msg *msg = (MailTest_Msg*) message;                            /* not "&message", the literal value itself!            */

    char *name = msg->name;
    char *food = msg->food;
    int age = msg->age;

    MailTest_Msg newMsg;
    strcpy(newMsg.name, name);
    strcpy(newMsg.food, food);
    newMsg.age = age+1;

    os_sendMsg(proc_name2, &newMsg);

    delayMicroseconds(250*1000);

    printf("-->Process 1 Mailbox - Exit\n");

    return;
}


//<Step 3> Grab message and pass into process2-thread
void process2_mailboxHandler(void *message) {

    printf("-->Process 2 Mailbox - Enter\n");

    MailTest_Msg *msg = (MailTest_Msg*) message;

    //Copy & Notify Process 2
    strcpy(proc2_msg.name, (char*)msg->name);
    strcpy(proc2_msg.food, (char*)msg->food);
    proc2_msg.age = msg->age;

    proc2_hasMsg = true;

    delayMicroseconds(250*1000);

    printf("-->Process 2 Mailbox - Exit\n");
    return;
}


//<Step 5> Grab message and pass into process3-thread
void process3_mailboxHandler(void *message) {

    printf("-->Process 3 Mailbox - Enter\n");

    MailTest_Msg *msg = (MailTest_Msg*) message;

    //Copy & Notify Process 2
    strcpy(proc3_msg.name, (char*)msg->name);
    strcpy(proc3_msg.food, (char*)msg->food);
    proc3_msg.age = msg->age;

    proc3_hasMsg = true;

    delayMicroseconds(250*1000);

    printf("-->Process 3 Mailbox - Exit\n");
    return;
}
