main.o: ../main.c ../globals.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h \
 ../core/os.h ../core/time.h ../test/test_mailbox.h ../test/../globals.h

../globals.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h:

../core/os.h:

../core/time.h:

../test/test_mailbox.h:

../test/../globals.h:
