/*
 * test_addProc.h
 *
 *  Created on: Jan 29, 2017
 *      Author: Owner
 */

#ifndef TEST_TEST_ADDPROC_H_
#define TEST_TEST_ADDPROC_H_


#include "../globals.h"


//Globals
extern void test_addProc(void);

char *procNames2[4];

#endif /* TEST_TEST_ADDPROC_H_ */
