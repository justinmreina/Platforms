main.o: ../main.c ../globals.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/bluetooth.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/hci.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/hci_lib.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h \
 ../core/log.h ../core/../globals.h ../core/time.h ../core/log.h \
 ../core/time.h ../core/delay.h

../globals.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/bluetooth.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/hci.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/bluetooth/hci_lib.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h:

../core/log.h:

../core/../globals.h:

../core/time.h:

../core/log.h:

../core/time.h:

../core/delay.h:
