#ifndef GLOBALS_H_
#define GLOBALS_H_

//Global Identity Defs
#define PROJ_NAME   "RPi3_Template_Project"


//Libraries
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

//Bluetooth
#include <unistd.h>
#include <sys/socket.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>

//WiringPi
#include <wiringPi/wiringPi.h>


//Project
#include "core/log.h"
#include "core/time.h"
#include "core/delay.h"


//Locals
void sys_init(void);
void sys_close(void);
void bluetoothDemo(void);
void flashDemo(void);

//defs
#define PIN_LED       (0)                                                   /* GPIO0                                                */
#define PIN_SW        (2)                                                   /* GPIO2                                                */


//Vars
#define FLASHDELAY_MS (2000)


#endif /* GLOBALS_H_ */
