#include "log.h"


FILE *os_logFile;


void os_log_init(void) {

    char fullFilePath[100] = {0};

    strcpy(fullFilePath, "./");                                             /* current directory                                    */
    strcpy(fullFilePath, PROJ_NAME);                                        /* project name                                         */
    strcat(fullFilePath, ".log");                                           /* log file                                             */

    os_logFile = fopen(fullFilePath, "w");
    os_log_write("os", "log file initialized", LOG_CODE_OK);

    return;
}


//source [date] "message" status-code
//e.g.
//local [10/Oct/1999:21:15:05 +0500] "cannot see user 1.2.3.4" 0
void os_log_write(char *source, char *message, uint32_t status_code) {

    char   dateStr[50] = {0};
    char   codeStr[50] = {0};
    char   logStr[100] = {0};

    //Format Vars to String
    os_time_getLocal(dateStr, 80);
    sprintf(codeStr, "%d", status_code);

    //Gen Log Line
    strcat(logStr, source);    //source
    strcat(logStr, "\t[");

    strcat(logStr, dateStr);    //[date]
    strcat(logStr, "] \"");

    strcat(logStr, message);    //"message"
    strcat(logStr, "\" ");

    strcat(logStr, codeStr);    //status-code
    strcat(logStr, " ");

    //Write
    fprintf(os_logFile, logStr);
    fprintf(os_logFile, "\n");

    //<temp>
    printf(logStr);
    printf("\n\r");

    return;
}


void os_log_get(char *dest) {

    return;
}


//note: this only covers to log, bluetooth can consider doing it's own log too
void os_log_set_bluetooth_logging(void) {

    return;
}


//pre: log is open
void os_log_close(void) {

    os_log_write("os", "Log file closed", LOG_CODE_OK);

    fclose(os_logFile);

    return;
}


//pre: log is initialized
//post: log is closed
void logDemo(void) {

    os_log_write("gym", "A", LOG_CODE_OK);
    os_log_write("gym", "B", LOG_CODE_OK);
    os_log_write("MySrc", "MyMsg", LOG_CODE_ERR);
    os_log_write("gym", "C-ish", LOG_CODE_OK);

    return;
}

