HelloGPIO.o: ../HelloGPIO.c ../globals.h \
 M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h

../globals.h:

M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib/wiringPi/wiringPi.h:
