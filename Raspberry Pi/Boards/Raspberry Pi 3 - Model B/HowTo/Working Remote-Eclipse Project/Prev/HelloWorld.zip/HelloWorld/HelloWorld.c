/*
 ============================================================================
 Name        : HelloWorld.c
 Author      : jmr
 Version     :
 Copyright   : Jmr copyright maybe
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	puts("Hello RPi you are complicated, but working so, yes..."); /* prints Hello RPi you are complicated, but working so, yes... */
	return EXIT_SUCCESS;
}

