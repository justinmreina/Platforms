#include <stdio.h>
#include <stdlib.h>

int main(void) {
	puts("Hello GPIO? Well Maybe???");
	return EXIT_SUCCESS;
}

