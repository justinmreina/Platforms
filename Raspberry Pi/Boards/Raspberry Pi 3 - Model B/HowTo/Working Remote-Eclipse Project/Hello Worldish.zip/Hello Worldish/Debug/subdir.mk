################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hello\ Worldish.c 

OBJS += \
./Hello\ Worldish.o 

C_DEPS += \
./Hello\ Worldish.d 


# Each subdirectory must supply rules for building sources it contributes
Hello\ Worldish.o: ../Hello\ Worldish.c
	@echo 'Building file: $<'
	@echo 'Invoking: Cross GCC Compiler'
	arm-linux-gnueabihf-gcc -I"M:\sw\rpi-eclipse\rpi-cross-toolchain\arm-linux-gnueabihf\lib" -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"Hello Worldish.d" -MT"Hello\ Worldish.d" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


